import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
  PlayerProfile,
  BodyMeasurement,
  HabitDefinition,
  HabitLog,
  Achievement,
  LevelUpEvent,
  CharacterAppearance,
} from './types/game';
import {
  GameStorageManager,
  INITIAL_PROFILE,
  DEFAULT_HABITS,
} from './utils/gameStorage';
import {
  calculateStreak,
  calculateWeeklyProgress,
  calculateAttributes,
  checkLevelUp,
  evaluateAchievements,
} from './utils/rpgCalculations';
import { soundEffects } from './utils/soundEffects';
import { TopHeader } from './components/layout/TopHeader';
import { BottomNavigation, NavTab } from './components/layout/BottomNavigation';
import { HeroHomeView } from './components/views/HeroHomeView';
import { MissionsView } from './components/views/MissionsView';
import { CalendarView } from './components/views/CalendarView';
import { StatsView } from './components/views/StatsView';
import { ProfileRPGView } from './components/views/ProfileRPGView';
import { XPRulesConfigView } from './components/views/XPRulesConfigView';
import { LevelUpModal } from './components/modals/LevelUpModal';
import { HabitLogModal } from './components/modals/HabitLogModal';
import { MeasurementModal } from './components/modals/MeasurementModal';

export default function App() {
  // Primary Game States
  const [profile, setProfile] = useState<PlayerProfile>(() => GameStorageManager.getProfile());
  const [measurements, setMeasurements] = useState<BodyMeasurement[]>(() => GameStorageManager.getMeasurements());
  const [habits, setHabits] = useState<HabitDefinition[]>(() => GameStorageManager.getHabits());
  const [logs, setLogs] = useState<HabitLog[]>(() => GameStorageManager.getLogs());
  const [achievements, setAchievements] = useState<Achievement[]>(() => GameStorageManager.getAchievements());

  // Navigation State
  const [activeTab, setActiveTab] = useState<NavTab>('hero');
  const [selectedDate, setSelectedDate] = useState<string>(() => new Date().toISOString().split('T')[0]);

  // Modal States
  const [levelUpEvent, setLevelUpEvent] = useState<LevelUpEvent | null>(null);
  const [editingHabitId, setEditingHabitId] = useState<string | null>(null);
  const [editingDate, setEditingDate] = useState<string>(selectedDate);
  const [isMeasurementModalOpen, setIsMeasurementModalOpen] = useState(false);
  const [achievementToast, setAchievementToast] = useState<Achievement | null>(null);

  // Synchronize sound effects enabled state with profile preference
  useEffect(() => {
    soundEffects.setEnabled(profile.soundEnabled);
  }, [profile.soundEnabled]);

  // Persistence helpers
  const updateProfileAndSave = useCallback((newProfile: PlayerProfile) => {
    setProfile(newProfile);
    GameStorageManager.saveProfile(newProfile);
  }, []);

  const updateMeasurementsAndSave = useCallback((newMeasurements: BodyMeasurement[]) => {
    setMeasurements(newMeasurements);
    GameStorageManager.saveMeasurements(newMeasurements);
  }, []);

  const updateHabitsAndSave = useCallback((newHabits: HabitDefinition[]) => {
    setHabits(newHabits);
    GameStorageManager.saveHabits(newHabits);
  }, []);

  const updateLogsAndSave = useCallback((newLogs: HabitLog[]) => {
    setLogs(newLogs);
    GameStorageManager.saveLogs(newLogs);
  }, []);

  const updateAchievementsAndSave = useCallback((newAchievements: Achievement[]) => {
    setAchievements(newAchievements);
    GameStorageManager.saveAchievements(newAchievements);
  }, []);

  // Calculated game values
  const { currentStreak, bestStreak } = useMemo(() => calculateStreak(logs), [logs]);

  const weeklyProgress = useMemo(() => calculateWeeklyProgress(habits, logs), [habits, logs]);

  const attributes = useMemo(
    () => calculateAttributes(logs, habits, currentStreak),
    [logs, habits, currentStreak]
  );

  const todayStr = useMemo(() => new Date().toISOString().split('T')[0], []);
  const todayLogs = useMemo(() => logs.filter((l) => l.date === todayStr), [logs, todayStr]);

  const pendingMissionsCount = useMemo(() => {
    const completedHabitIds = new Set(
      todayLogs.filter((l) => l.status === 'completed').map((l) => l.habitId)
    );
    const visibleHabits = habits.filter((h) => !h.isPrivate || !profile.privateModeHidden);
    return visibleHabits.filter((h) => !completedHabitIds.has(h.id)).length;
  }, [todayLogs, habits, profile.privateModeHidden]);

  // Handle Level Ups and XP Awarding
  const addXP = useCallback(
    (xp: number) => {
      const { updatedProfile, levelUpEvent: lvlEvt } = checkLevelUp(profile, xp);
      updateProfileAndSave(updatedProfile);

      if (lvlEvt) {
        setLevelUpEvent(lvlEvt);
      }

      // Check achievements after XP or level change
      const { updatedAchievements, newlyUnlocked } = evaluateAchievements(
        achievements,
        logs,
        updatedProfile,
        measurements
      );
      if (newlyUnlocked.length > 0) {
        updateAchievementsAndSave(updatedAchievements);
        const firstNew = newlyUnlocked[0];
        setAchievementToast(firstNew);
        if (profile.soundEnabled) soundEffects.playAchievement();
        setTimeout(() => setAchievementToast(null), 4500);
      }
    },
    [profile, achievements, logs, measurements, updateProfileAndSave, updateAchievementsAndSave]
  );

  // Quick 1-tap Habit Complete/Pending toggle
  const handleQuickToggleHabit = useCallback(
    (habitId: string) => {
      const existing = todayLogs.find((l) => l.habitId === habitId);
      const habit = habits.find((h) => h.id === habitId);
      if (!habit) return;

      const isCompleted = existing?.status === 'completed';
      const newStatus = isCompleted ? 'pending' : 'completed';

      let newLogs: HabitLog[];
      if (existing) {
        newLogs = logs.map((l) =>
          l.id === existing.id
            ? {
                ...l,
                status: newStatus,
                xpAwarded: newStatus === 'completed' ? habit.baseXP : 0,
              }
            : l
        );
      } else {
        const newLog: HabitLog = {
          id: `log-${habitId}-${todayStr}-${Date.now()}`,
          habitId: habit.id,
          date: todayStr,
          status: 'completed',
          sessionsCount: 1,
          metricValue: habit.id === 'running' ? 5.0 : habit.id === 'drawing' ? 30 : 16,
          xpAwarded: habit.baseXP,
          timestamp: new Date().toISOString(),
        };
        newLogs = [...logs, newLog];
      }

      updateLogsAndSave(newLogs);

      if (newStatus === 'completed') {
        if (profile.soundEnabled) soundEffects.playMissionComplete();
        addXP(habit.baseXP);
      } else {
        soundEffects.playClick();
      }
    },
    [todayLogs, habits, logs, todayStr, profile.soundEnabled, updateLogsAndSave, addXP]
  );

  // Save detailed habit log from modal
  const handleSaveLog = useCallback(
    (logData: Omit<HabitLog, 'id' | 'timestamp'>) => {
      const existingIndex = logs.findIndex(
        (l) => l.habitId === logData.habitId && l.date === logData.date
      );
      let newLogs: HabitLog[];

      if (existingIndex >= 0) {
        newLogs = [...logs];
        newLogs[existingIndex] = {
          ...newLogs[existingIndex],
          ...logData,
          timestamp: new Date().toISOString(),
        };
      } else {
        const newLog: HabitLog = {
          id: `log-${logData.habitId}-${logData.date}-${Date.now()}`,
          ...logData,
          timestamp: new Date().toISOString(),
        };
        newLogs = [...logs, newLog];
      }

      updateLogsAndSave(newLogs);

      if (logData.status === 'completed') {
        if (profile.soundEnabled) soundEffects.playMissionComplete();
        addXP(logData.xpAwarded);
      }
    },
    [logs, profile.soundEnabled, updateLogsAndSave, addXP]
  );

  // Save new body measurement (morphs the character!)
  const handleSaveMeasurement = useCallback(
    (measurement: BodyMeasurement) => {
      const updatedMeasurements = [...measurements, measurement];
      updateMeasurementsAndSave(updatedMeasurements);

      // Update current weight, body fat and muscle in profile
      const updatedProfile: PlayerProfile = {
        ...profile,
        currentWeightKg: measurement.weightKg,
        currentBodyFatPercent: measurement.bodyFatPercent,
        currentMuscleMassKg: measurement.muscleMassKg || profile.currentMuscleMassKg,
      };
      updateProfileAndSave(updatedProfile);

      if (profile.soundEnabled) soundEffects.playLevelUp();
      addXP(100); // 100 XP for tracking measurements!
    },
    [measurements, profile, updateMeasurementsAndSave, updateProfileAndSave, addXP]
  );

  // Update Appearance
  const handleUpdateAppearance = useCallback(
    (changes: Partial<CharacterAppearance>) => {
      const updatedProfile: PlayerProfile = {
        ...profile,
        appearance: {
          ...profile.appearance,
          ...changes,
        },
      };
      updateProfileAndSave(updatedProfile);
    },
    [profile, updateProfileAndSave]
  );

  // Update Habit Goal
  const handleUpdateHabitGoals = useCallback(
    (habitId: string, newGoal: number) => {
      const updatedHabits = habits.map((h) =>
        h.id === habitId ? { ...h, weeklyGoalSessions: Math.max(1, newGoal) } : h
      );
      updateHabitsAndSave(updatedHabits);
    },
    [habits, updateHabitsAndSave]
  );

  // Export Data JSON
  const handleExportData = useCallback(() => {
    const json = GameStorageManager.exportAllData();
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `rpg-mi-evolucion-backup-${todayStr}.json`;
    a.click();
    URL.revokeObjectURL(url);
    if (profile.soundEnabled) soundEffects.playClick();
  }, [todayStr, profile.soundEnabled]);

  // Import Data JSON
  const handleImportData = useCallback(
    (json: string): boolean => {
      const ok = GameStorageManager.importAllData(json);
      if (ok) {
        setProfile(GameStorageManager.getProfile());
        setMeasurements(GameStorageManager.getMeasurements());
        setHabits(GameStorageManager.getHabits());
        setLogs(GameStorageManager.getLogs());
        setAchievements(GameStorageManager.getAchievements());
      }
      return ok;
    },
    []
  );

  // Reset to initial sample data
  const handleResetData = useCallback(() => {
    GameStorageManager.resetToInitial();
    setProfile(GameStorageManager.getProfile());
    setMeasurements(GameStorageManager.getMeasurements());
    setHabits(GameStorageManager.getHabits());
    setLogs(GameStorageManager.getLogs());
    setAchievements(GameStorageManager.getAchievements());
    soundEffects.playClick();
  }, []);

  const editingHabit = habits.find((h) => h.id === editingHabitId) || habits[0];
  const editingExistingLog = logs.find(
    (l) => l.habitId === editingHabitId && l.date === editingDate
  );

  return (
    <div className="min-h-screen bg-[#080c14] text-slate-100 flex flex-col selection:bg-cyan-500/30">
      {/* Top Header */}
      <TopHeader
        currentStreak={currentStreak}
        soundEnabled={profile.soundEnabled}
        onToggleSound={() => {
          const next = !profile.soundEnabled;
          soundEffects.setEnabled(next);
          updateProfileAndSave({ ...profile, soundEnabled: next });
        }}
        level={profile.level}
        onOpenNewMeasurement={() => setIsMeasurementModalOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-xl w-full mx-auto px-3.5 pt-3">
        {activeTab === 'hero' && (
          <HeroHomeView
            profile={profile}
            habits={habits}
            todayLogs={todayLogs}
            attributes={attributes}
            weeklyProgress={weeklyProgress}
            currentStreak={currentStreak}
            onQuickToggleHabit={handleQuickToggleHabit}
            onOpenHabitDetail={(id) => {
              setEditingHabitId(id);
              setEditingDate(todayStr);
            }}
            onNavigateToTab={(tab) => {
              soundEffects.playClick();
              setActiveTab(tab);
            }}
            onUpdateAppearance={handleUpdateAppearance}
          />
        )}

        {activeTab === 'missions' && (
          <MissionsView
            habits={habits}
            logs={logs}
            profile={profile}
            selectedDate={selectedDate}
            onSelectDate={setSelectedDate}
            onSaveLog={handleSaveLog}
            onOpenHabitDetail={(id) => {
              setEditingHabitId(id);
              setEditingDate(selectedDate);
            }}
            onUpdateHabitGoals={handleUpdateHabitGoals}
            onNavigateToRules={() => {
              soundEffects.playClick();
              setActiveTab('rules');
            }}
          />
        )}

        {activeTab === 'rules' && (
          <XPRulesConfigView
            habits={habits}
            onUpdateHabits={updateHabitsAndSave}
            onResetHabitsToDefault={() => {
              updateHabitsAndSave(DEFAULT_HABITS);
              soundEffects.playLevelUp();
            }}
          />
        )}

        {activeTab === 'calendar' && (
          <CalendarView
            habits={habits}
            logs={logs}
            onSelectDate={(date) => {
              setSelectedDate(date);
              setActiveTab('missions');
            }}
            onOpenHabitLogModal={(id, date) => {
              setEditingHabitId(id);
              setEditingDate(date);
            }}
          />
        )}

        {activeTab === 'stats' && (
          <StatsView
            profile={profile}
            measurements={measurements}
            logs={logs}
            habits={habits}
            attributes={attributes}
            achievements={achievements}
            currentStreak={currentStreak}
            bestStreak={bestStreak}
            onOpenMeasurementModal={() => setIsMeasurementModalOpen(true)}
          />
        )}

        {activeTab === 'profile' && (
          <ProfileRPGView
            profile={profile}
            achievements={achievements}
            pendingMissionsCount={pendingMissionsCount}
            onUpdateProfile={(updated) => updateProfileAndSave({ ...profile, ...updated })}
            onUpdateAppearance={handleUpdateAppearance}
            onExportData={handleExportData}
            onImportData={handleImportData}
            onResetData={handleResetData}
            onOpenMeasurementModal={() => setIsMeasurementModalOpen(true)}
          />
        )}
      </main>

      {/* Bottom Ergonomic Navigation Bar */}
      <BottomNavigation
        activeTab={activeTab}
        onTabChange={(tab) => {
          soundEffects.playClick();
          setActiveTab(tab);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        pendingMissionsCount={pendingMissionsCount}
      />

      {/* Achievement Unlocked Toast Banner */}
      {achievementToast && (
        <div className="fixed top-16 left-1/2 -translate-x-1/2 z-50 w-[90%] max-w-sm p-3.5 rounded-2xl bg-gradient-to-r from-amber-950 via-slate-900 to-amber-950 border-2 border-amber-400 shadow-2xl shadow-amber-500/40 animate-in slide-in-from-top-4 duration-300">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center font-bold shrink-0">
              🏆
            </div>
            <div>
              <span className="text-[10px] font-black tracking-wider text-amber-300 uppercase block">
                ¡LOGRO DESBLOQUEADO!
              </span>
              <h4 className="text-xs font-black text-white">{achievementToast.title}</h4>
              <p className="text-[10px] text-slate-300 mt-0.5">+{achievementToast.xpReward} XP</p>
            </div>
          </div>
        </div>
      )}

      {/* Level Up Spectacular Modal */}
      {levelUpEvent && (
        <LevelUpModal
          event={levelUpEvent}
          soundEnabled={profile.soundEnabled}
          onClose={() => setLevelUpEvent(null)}
        />
      )}

      {/* Habit Log & Edit Modal */}
      {editingHabitId && (
        <HabitLogModal
          habit={editingHabit}
          date={editingDate}
          existingLog={editingExistingLog}
          onSave={handleSaveLog}
          onClose={() => setEditingHabitId(null)}
        />
      )}

      {/* Physical Measurement Modal */}
      {isMeasurementModalOpen && (
        <MeasurementModal
          currentHeightCm={profile.heightCm}
          lastMeasurement={measurements[measurements.length - 1]}
          onSave={handleSaveMeasurement}
          onClose={() => setIsMeasurementModalOpen(false)}
        />
      )}
    </div>
  );
}
