import React from 'react';
import { Volume2, VolumeX, Flame } from 'lucide-react';
import { soundEffects } from '../../utils/soundEffects';

interface TopHeaderProps {
  currentStreak: number;
  soundEnabled: boolean;
  onToggleSound: () => void;
  level: number;
  onOpenNewMeasurement: () => void;
}

export const TopHeader: React.FC<TopHeaderProps> = ({
  currentStreak,
  soundEnabled,
  onToggleSound,
  level,
  onOpenNewMeasurement,
}) => {
  return (
    <header className="sticky top-0 z-30 flex items-center justify-between gap-4 px-4 py-3 bg-[#080d1a]/90 backdrop-blur-xl border-b border-slate-800/80">
      {/* Zone 1: Brand Wordmark */}
      <div className="flex items-center gap-2 shrink-0">
        <span className="text-sm font-black tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-blue-400 to-indigo-300 font-rpg uppercase whitespace-nowrap">
          Mi Propia Evolución
        </span>
      </div>

      {/* Zone 2: Streak & Level Indicators */}
      <div className="flex items-center gap-2 text-xs font-medium text-slate-300 shrink-0">
        <div className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-900 border border-amber-500/30 text-amber-400">
          <Flame className="w-3.5 h-3.5 fill-amber-500 text-amber-400" />
          <span className="font-mono-num font-bold text-xs">{currentStreak}</span>
          <span className="text-[10px] text-slate-400 font-sans hidden sm:inline">días</span>
        </div>

        <div className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-900 border border-cyan-500/30 text-cyan-400">
          <span className="text-[10px] font-bold">NVL</span>
          <span className="font-mono-num font-bold text-xs">{level}</span>
        </div>
      </div>

      {/* Zone 3: Primary Action & Sound Toggle */}
      <div className="flex items-center gap-2 shrink-0">
        <button
          onClick={onToggleSound}
          title={soundEnabled ? 'Silenciar sonidos' : 'Activar sonidos'}
          className={`p-2 rounded-lg border transition ${
            soundEnabled
              ? 'bg-slate-900 border-slate-700 text-cyan-400 hover:text-white'
              : 'bg-slate-950 border-slate-800 text-slate-500 hover:text-slate-400'
          }`}
        >
          {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
        </button>

        <button
          onClick={() => {
            soundEffects.playClick();
            onOpenNewMeasurement();
          }}
          className="px-3 py-1.5 text-xs font-bold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-lg shadow-sm shadow-cyan-500/20 active:scale-[0.98] transition-all whitespace-nowrap"
        >
          + Medición
        </button>
      </div>
    </header>
  );
};
