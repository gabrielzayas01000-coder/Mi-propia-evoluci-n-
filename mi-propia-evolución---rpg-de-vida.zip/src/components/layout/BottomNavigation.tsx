import React from 'react';
import { Shield, Target, Calendar, BarChart3, User, Sliders } from 'lucide-react';

export type NavTab = 'hero' | 'missions' | 'rules' | 'calendar' | 'stats' | 'profile';

interface BottomNavigationProps {
  activeTab: NavTab;
  onTabChange: (tab: NavTab) => void;
  pendingMissionsCount: number;
}

export const BottomNavigation: React.FC<BottomNavigationProps> = ({
  activeTab,
  onTabChange,
  pendingMissionsCount,
}) => {
  const tabs = [
    { id: 'hero' as NavTab, label: 'Héroe', icon: Shield },
    { id: 'missions' as NavTab, label: 'Misiones', icon: Target, badge: pendingMissionsCount },
    { id: 'rules' as NavTab, label: 'Reglas EXP', icon: Sliders },
    { id: 'calendar' as NavTab, label: 'Calendario', icon: Calendar },
    { id: 'stats' as NavTab, label: 'Evolución', icon: BarChart3 },
    { id: 'profile' as NavTab, label: 'Mi Perfil', icon: User },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-[#080d1a]/95 backdrop-blur-xl border-t border-slate-800/80 safe-area-bottom shadow-2xl">
      <div className="max-w-xl mx-auto grid grid-cols-6 h-16 px-0.5">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className={`relative flex flex-col items-center justify-center min-h-[48px] py-1 transition-all ${
                isActive ? 'text-cyan-400' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <div className="relative">
                <Icon
                  className={`w-5 h-5 transition-transform ${
                    isActive ? 'scale-110 drop-shadow-[0_0_8px_rgba(6,182,212,0.6)]' : ''
                  }`}
                />
                {tab.badge && tab.badge > 0 ? (
                  <span className="absolute -top-1.5 -right-2 flex items-center justify-center min-w-[15px] h-3.5 px-0.5 rounded-full bg-cyan-500 text-[8px] font-black text-slate-950 font-mono-num">
                    {tab.badge}
                  </span>
                ) : null}
              </div>
              <span
                className={`text-[9.5px] font-semibold tracking-tight mt-1 truncate max-w-[54px] ${
                  isActive ? 'text-cyan-300 font-bold' : 'text-slate-400'
                }`}
              >
                {tab.label}
              </span>
              {isActive && (
                <span className="absolute bottom-1 w-5 h-0.5 rounded-full bg-cyan-400 shadow-[0_0_6px_#38bdf8]" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
