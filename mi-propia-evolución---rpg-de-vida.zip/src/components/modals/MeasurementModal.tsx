import React, { useState } from 'react';
import { BodyMeasurement } from '../../types/game';
import { Scale, Activity } from 'lucide-react';

interface MeasurementModalProps {
  currentHeightCm: number;
  lastMeasurement?: BodyMeasurement;
  onSave: (measurement: BodyMeasurement) => void;
  onClose: () => void;
}

export const MeasurementModal: React.FC<MeasurementModalProps> = ({
  currentHeightCm,
  lastMeasurement,
  onSave,
  onClose,
}) => {
  const [date, setDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [weightKg, setWeightKg] = useState<string>(
    lastMeasurement?.weightKg ? String(lastMeasurement.weightKg) : '85.0'
  );
  const [bodyFatPercent, setBodyFatPercent] = useState<string>(
    lastMeasurement?.bodyFatPercent ? String(lastMeasurement.bodyFatPercent) : '25.0'
  );
  const [muscleMassKg, setMuscleMassKg] = useState<string>(
    lastMeasurement?.muscleMassKg ? String(lastMeasurement.muscleMassKg) : '34.0'
  );
  const [waistCm, setWaistCm] = useState<string>(
    lastMeasurement?.waistCm ? String(lastMeasurement.waistCm) : '90'
  );
  const [notes, setNotes] = useState<string>('');

  const numWeight = parseFloat(weightKg) || 80;
  const numFat = parseFloat(bodyFatPercent) || 20;
  const numMuscle = parseFloat(muscleMassKg) || (numWeight * (1 - numFat / 100) * 0.48);

  // Calculated App Metrics (Clearly distinguished from manual entries)
  const heightInMeters = currentHeightCm / 100;
  const calculatedImc = parseFloat((numWeight / (heightInMeters * heightInMeters)).toFixed(1));
  const estimatedLeanMass = parseFloat((numWeight * (1 - numFat / 100)).toFixed(1));

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newMeasurement: BodyMeasurement = {
      id: `meas-${Date.now()}`,
      date,
      weightKg: parseFloat(numWeight.toFixed(1)),
      bodyFatPercent: parseFloat(numFat.toFixed(1)),
      muscleMassKg: muscleMassKg ? parseFloat(numMuscle.toFixed(1)) : undefined,
      waistCm: waistCm ? parseFloat(waistCm) : undefined,
      notes: notes.trim(),
      isManual: true,
      calculatedImc,
    };
    onSave(newMeasurement);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="relative w-full max-w-md rounded-2xl bg-[#0d1424] border border-slate-800 p-5 shadow-2xl overflow-hidden max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-cyan-950/60 border border-cyan-800 text-cyan-400">
              <Scale className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white font-rpg">Registrar Medición Física</h3>
              <p className="text-xs text-slate-400">Actualiza tus datos para transformar tu personaje</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            ✕
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-4 space-y-4">
          {/* Date Picker */}
          <div>
            <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">
              Fecha de la medición
            </label>
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-white font-mono-num text-sm focus:outline-none focus:border-cyan-500"
            />
          </div>

          {/* Section: Manual Data Entry */}
          <div className="p-3 bg-slate-900/60 rounded-xl border border-slate-800/80 space-y-3">
            <div className="flex items-center gap-2 text-xs font-semibold text-cyan-400 uppercase tracking-wider">
              <span>● Datos Introducidos Manualmente</span>
            </div>

            <div className="grid grid-cols-2 gap-3">
              {/* Peso actual */}
              <div>
                <label className="block text-xs text-slate-300 font-medium mb-1">
                  Peso actual (kg) *
                </label>
                <input
                  type="number"
                  step="0.1"
                  min="30"
                  max="250"
                  required
                  value={weightKg}
                  onChange={(e) => setWeightKg(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white font-mono-num font-bold text-sm focus:outline-none focus:border-cyan-500"
                />
              </div>

              {/* % Grasa Corporal */}
              <div>
                <label className="block text-xs text-slate-300 font-medium mb-1">
                  % Grasa corporal *
                </label>
                <input
                  type="number"
                  step="0.1"
                  min="4"
                  max="60"
                  required
                  value={bodyFatPercent}
                  onChange={(e) => setBodyFatPercent(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-cyan-400 font-mono-num font-bold text-sm focus:outline-none focus:border-cyan-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              {/* Masa Muscular */}
              <div>
                <label className="block text-xs text-slate-300 font-medium mb-1">
                  Masa muscular (kg) <span className="text-slate-500 font-normal">(opc.)</span>
                </label>
                <input
                  type="number"
                  step="0.1"
                  min="15"
                  max="120"
                  value={muscleMassKg}
                  onChange={(e) => setMuscleMassKg(e.target.value)}
                  placeholder="Ej. 34.2"
                  className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white font-mono-num text-sm focus:outline-none focus:border-cyan-500"
                />
              </div>

              {/* Perímetro de cintura */}
              <div>
                <label className="block text-xs text-slate-300 font-medium mb-1">
                  Cintura (cm) <span className="text-slate-500 font-normal">(opc.)</span>
                </label>
                <input
                  type="number"
                  step="0.5"
                  min="40"
                  max="180"
                  value={waistCm}
                  onChange={(e) => setWaistCm(e.target.value)}
                  placeholder="Ej. 88"
                  className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white font-mono-num text-sm focus:outline-none focus:border-cyan-500"
                />
              </div>
            </div>
          </div>

          {/* Section: Calculated Statistics (Transparently differentiated) */}
          <div className="p-3 bg-slate-900/30 rounded-xl border border-dashed border-slate-700/60 space-y-2">
            <div className="flex items-center gap-1.5 text-xs text-slate-400 font-medium">
              <Activity className="w-3.5 h-3.5 text-amber-400" />
              <span>Estadísticas Calculadas por la App (No manuales)</span>
            </div>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="p-2 rounded-lg bg-slate-950/60 flex items-center justify-between">
                <span className="text-slate-400">IMC Calculado:</span>
                <span className="font-bold text-white font-mono-num">{calculatedImc}</span>
              </div>
              <div className="p-2 rounded-lg bg-slate-950/60 flex items-center justify-between">
                <span className="text-slate-400">Masa Magra Est.:</span>
                <span className="font-bold text-cyan-400 font-mono-num">{estimatedLeanMass} kg</span>
              </div>
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1">
              Notas de la medición
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Ej. Medición en ayunas tras 3 semanas de entrenamiento constante..."
              className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-white text-xs focus:outline-none focus:border-cyan-500 resize-none"
            />
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 text-xs font-medium"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs shadow-md shadow-cyan-500/20 active:scale-[0.98] transition"
            >
              Guardar y Evolucionar
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
