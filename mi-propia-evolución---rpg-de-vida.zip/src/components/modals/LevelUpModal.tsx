import React, { useEffect } from 'react';
import confetti from 'canvas-confetti';
import { LevelUpEvent } from '../../types/game';
import { soundEffects } from '../../utils/soundEffects';

interface LevelUpModalProps {
  event: LevelUpEvent | null;
  onClose: () => void;
  soundEnabled: boolean;
}

export const LevelUpModal: React.FC<LevelUpModalProps> = ({ event, onClose, soundEnabled }) => {
  useEffect(() => {
    if (event) {
      if (soundEnabled) {
        soundEffects.playLevelUp();
      }
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#38bdf8', '#fbbf24', '#f43f5e', '#34d399', '#a855f7'],
        });
      } catch {
        // Fallback
      }
    }
  }, [event, soundEnabled]);

  if (!event) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-sm rounded-2xl bg-gradient-to-b from-slate-900 via-[#0b1324] to-slate-950 border-2 border-cyan-500/60 p-6 text-center shadow-2xl shadow-cyan-500/30 overflow-hidden">
        {/* Glow beams */}
        <div className="absolute -top-24 left-1/2 -translate-x-1/2 w-48 h-48 bg-cyan-500/20 rounded-full blur-3xl pointer-events-none" />

        {/* Level Up Banner */}
        <div className="relative z-10 flex flex-col items-center">
          <div className="text-[11px] font-black tracking-widest text-cyan-400 uppercase">
            ¡SUBIDA DE NIVEL!
          </div>

          {/* Level Circle */}
          <div className="my-4 relative flex items-center justify-center w-24 h-24 rounded-full bg-slate-950 border-4 border-amber-400 shadow-xl shadow-amber-500/30">
            <span className="text-4xl font-black text-amber-300 font-mono-num">{event.newLevel}</span>
          </div>

          <h2 className="text-xl font-black text-white font-rpg tracking-wide">
            {event.titleUnlocked || 'Rango Ascendido'}
          </h2>

          <p className="mt-1 text-xs text-slate-300">
            Tu disciplina constante ha dado frutos. Tu poder y atributos han aumentado.
          </p>

          {/* Stat Boosts */}
          <div className="w-full mt-4 p-3 bg-slate-900/80 rounded-xl border border-slate-800 text-left">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-2">
              Mejoras de Atributo
            </span>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="flex items-center justify-between text-slate-300">
                <span>Fuerza:</span>
                <span className="text-emerald-400 font-bold font-mono-num">+{event.attributeBoosts.strength}</span>
              </div>
              <div className="flex items-center justify-between text-slate-300">
                <span>Resistencia:</span>
                <span className="text-emerald-400 font-bold font-mono-num">+{event.attributeBoosts.endurance}</span>
              </div>
              <div className="flex items-center justify-between text-slate-300">
                <span>Creatividad:</span>
                <span className="text-emerald-400 font-bold font-mono-num">+{event.attributeBoosts.creativity}</span>
              </div>
              <div className="flex items-center justify-between text-slate-300">
                <span>Disciplina:</span>
                <span className="text-emerald-400 font-bold font-mono-num">+{event.attributeBoosts.discipline}</span>
              </div>
            </div>
          </div>

          {/* Confirm Button */}
          <button
            onClick={onClose}
            className="w-full mt-5 py-3 px-4 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-sm tracking-wide shadow-lg shadow-cyan-500/25 active:scale-[0.98] transition-transform"
          >
            Continuar la Aventura
          </button>
        </div>
      </div>
    </div>
  );
};
