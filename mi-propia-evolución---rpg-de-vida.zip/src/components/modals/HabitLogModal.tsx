import React, { useState } from 'react';
import { HabitDefinition, HabitLog, HabitStatus } from '../../types/game';
import { CheckCircle2, Clock, XCircle, Dumbbell, Footprints, Palette, Shield, Flame } from 'lucide-react';

interface HabitLogModalProps {
  habit: HabitDefinition;
  date: string;
  existingLog?: HabitLog;
  onSave: (log: Omit<HabitLog, 'id' | 'timestamp'>) => void;
  onClose: () => void;
}

export const HabitLogModal: React.FC<HabitLogModalProps> = ({
  habit,
  date,
  existingLog,
  onSave,
  onClose,
}) => {
  const [status, setStatus] = useState<HabitStatus>(existingLog?.status || 'completed');
  const [sessionsCount, setSessionsCount] = useState<number>(existingLog?.sessionsCount || 1);
  const [metricValue, setMetricValue] = useState<string>(
    existingLog?.metricValue ? String(existingLog.metricValue) : habit.id === 'running' ? '5.0' : habit.id === 'drawing' ? '45' : '16'
  );
  const [notes, setNotes] = useState<string>(existingLog?.notes || '');

  const getHabitIcon = (id: string) => {
    switch (id) {
      case 'gym':
        return <Dumbbell className="w-5 h-5 text-blue-400" />;
      case 'running':
        return <Footprints className="w-5 h-5 text-cyan-400" />;
      case 'drawing':
        return <Palette className="w-5 h-5 text-amber-400" />;
      case 'abstinence':
        return <Shield className="w-5 h-5 text-purple-400" />;
      default:
        return <Flame className="w-5 h-5 text-cyan-400" />;
    }
  };

  const metricNum = parseFloat(metricValue) || 0;
  const metricBonus = Math.round(metricNum * (habit.metricBonusRate || 0));
  const calculatedXP = status === 'completed' ? habit.baseXP * Math.max(1, sessionsCount) + metricBonus : 0;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      habitId: habit.id,
      date,
      status,
      sessionsCount: Math.max(1, sessionsCount),
      metricValue: metricValue ? parseFloat(metricValue) : undefined,
      notes: notes.trim(),
      xpAwarded: calculatedXP,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="relative w-full max-w-md rounded-2xl bg-[#0d1424] border border-slate-800 p-5 shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-700/60">
              {getHabitIcon(habit.id)}
            </div>
            <div>
              <h3 className="text-base font-bold text-white font-rpg">{habit.name}</h3>
              <p className="text-xs text-slate-400">
                Fecha: <span className="font-mono-num text-slate-300">{date}</span> · {habit.category}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            ✕
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-4 space-y-4">
          {/* Status Selector */}
          <div>
            <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
              Estado de la Actividad
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setStatus('completed')}
                className={`flex flex-col items-center justify-center p-2.5 rounded-xl border text-xs font-medium transition ${
                  status === 'completed'
                    ? 'bg-emerald-950/60 border-emerald-500 text-emerald-300 shadow-sm'
                    : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:border-slate-700'
                }`}
              >
                <CheckCircle2 className="w-5 h-5 mb-1 text-emerald-400" />
                <span>Completada</span>
                <span className="text-[10px] text-emerald-400 font-mono-num mt-0.5">+{habit.baseXP} XP</span>
              </button>

              <button
                type="button"
                onClick={() => setStatus('pending')}
                className={`flex flex-col items-center justify-center p-2.5 rounded-xl border text-xs font-medium transition ${
                  status === 'pending'
                    ? 'bg-amber-950/60 border-amber-500 text-amber-300 shadow-sm'
                    : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:border-slate-700'
                }`}
              >
                <Clock className="w-5 h-5 mb-1 text-amber-400" />
                <span>Pendiente</span>
                <span className="text-[10px] text-slate-400 mt-0.5">Sin penalización</span>
              </button>

              <button
                type="button"
                onClick={() => setStatus('skipped')}
                className={`flex flex-col items-center justify-center p-2.5 rounded-xl border text-xs font-medium transition ${
                  status === 'skipped'
                    ? 'bg-slate-800 border-slate-600 text-slate-300 shadow-sm'
                    : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:border-slate-700'
                }`}
              >
                <XCircle className="w-5 h-5 mb-1 text-slate-400" />
                <span>No realizada</span>
                <span className="text-[10px] text-slate-500 mt-0.5">Día de descanso</span>
              </button>
            </div>
          </div>

          {/* Conditional Metrics (Only relevant if completed) */}
          {status === 'completed' && (
            <div className="space-y-3 pt-2">
              <div className="grid grid-cols-2 gap-3">
                {/* Number of sessions */}
                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-1">
                    Sesiones realizadas
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="5"
                    value={sessionsCount}
                    onChange={(e) => setSessionsCount(parseInt(e.target.value) || 1)}
                    className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-white font-mono-num text-sm focus:outline-none focus:border-cyan-500"
                  />
                </div>

                {/* Specific Metric (e.g. km or minutes) */}
                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-1">
                    {habit.metricLabel} ({habit.metricUnit})
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    min="0"
                    value={metricValue}
                    onChange={(e) => setMetricValue(e.target.value)}
                    placeholder="Ej. 5.2"
                    className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-white font-mono-num text-sm focus:outline-none focus:border-cyan-500"
                  />
                </div>
              </div>

              {habit.id === 'abstinence' && (
                <div className="p-2.5 rounded-lg bg-purple-950/30 border border-purple-800/40 text-xs text-purple-300">
                  <span className="font-semibold block mb-0.5">Enfoque consciente</span>
                  Registro neutral y privado para cultivar tu autodominio y vitalidad.
                </div>
              )}
            </div>
          )}

          {/* Optional Notes */}
          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1">
              Notas personales opcionales
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Sensaciones, récord personal, ejercicios realizados..."
              className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-white text-xs focus:outline-none focus:border-cyan-500 resize-none"
            />
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 text-xs font-medium"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs shadow-md shadow-cyan-500/20 active:scale-[0.98] transition"
            >
              Guardar Registro
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
