import React from 'react';
import { CharacterAppearance, ViewAngle, CharacterPose } from '../../types/game';

interface CharacterCanvasProps {
  appearance: CharacterAppearance;
  weightKg: number;
  bodyFatPercent: number;
  muscleMassKg?: number;
  heightCm: number;
  level: number;
  interactive?: boolean;
  onViewChange?: (view: ViewAngle) => void;
  onPoseChange?: (pose: CharacterPose) => void;
  className?: string;
  showBackdrop?: boolean;
  size?: 'sm' | 'md' | 'lg' | 'hero';
}

export const CharacterCanvas: React.FC<CharacterCanvasProps> = ({
  appearance,
  weightKg,
  bodyFatPercent,
  muscleMassKg,
  heightCm = 175,
  level = 1,
  interactive = true,
  onViewChange,
  onPoseChange,
  className = '',
  showBackdrop = true,
  size = 'hero',
}) => {
  const {
    skinTone,
    hairStyle,
    hairColor,
    eyeColor = '#38bdf8',
    eyeStyle = 'heroic_sharp',
    faceShape = 'sharp_v',
    facialHair,
    facialHairColor,
    outfit,
    outfitColor,
    accessory,
    katanaOnBack = false,
    auraEffect,
    artStyle = 'anime',
    currentPose,
    viewAngle,
  } = appearance;

  // Normalized morphing ratios
  const fatFactor = Math.min(Math.max((bodyFatPercent - 8) / 27, 0), 1);
  const estimatedMuscle = muscleMassKg || (weightKg * (1 - bodyFatPercent / 100) * 0.48);
  const muscleFactor = Math.min(Math.max((estimatedMuscle - 22) / 26, 0), 1);

  // Anatomical geometry for SVG (viewBox 0 0 320 440, center is X: 160)
  const shoulderWidth = 48 + muscleFactor * 28 - fatFactor * 5;
  const waistWidth = 24 + fatFactor * 32 - muscleFactor * 7;
  const chestWidth = 38 + muscleFactor * 22 + fatFactor * 12;
  const bicepSize = 14 + muscleFactor * 14 + fatFactor * 4;
  const legThick = 22 + muscleFactor * 11 + fatFactor * 12;
  const bellyBulge = fatFactor * 30; // Prominently displayed in side & front profile
  const faceRoundness = (faceShape === 'sharp_v' ? 14 : faceShape === 'athletic_jaw' ? 17 : 20) + fatFactor * 8 - muscleFactor * 2;

  // Abs visibility: under 18% begins showing, under 14% sharp cel-shaded anime cuts
  const absOpacity = Math.max(0, Math.min(1, (18 - bodyFatPercent) / 7));
  const muscleDefinition = Math.max(0.2, Math.min(1, muscleFactor * 1.15));

  // Determine stage visual rank
  const isHighLevel = level >= 10;

  return (
    <div className={`relative flex flex-col items-center justify-center select-none ${className}`}>
      {/* Viewport Box */}
      <div
        className={`relative w-full overflow-hidden rounded-2xl flex items-center justify-center ${
          size === 'sm' ? 'h-48' : size === 'md' ? 'h-72' : size === 'lg' ? 'h-96' : 'h-[390px] sm:h-[440px]'
        }`}
      >
        {/* Anime Dojo Training Backdrop */}
        {showBackdrop && (
          <div className="absolute inset-0 z-0">
            <img
              src="/src/assets/images/rpg_dojo_backdrop_1792226482492.jpg"
              alt="Dojo Anime RPG"
              className="w-full h-full object-cover opacity-40 filter brightness-75 contrast-125 transition-opacity"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#080c14] via-[#080c14]/40 to-[#080c14]/75" />
            <div className="absolute inset-0 bg-gradient-to-r from-[#080c14]/70 via-transparent to-[#080c14]/70" />
          </div>
        )}

        {/* Dynamic Anime Aura Glow */}
        {auraEffect !== 'none' && (
          <div
            className={`absolute z-1 pointer-events-none rounded-full blur-3xl opacity-60 animate-aura ${
              auraEffect === 'ki_blue'
                ? 'bg-cyan-500 w-64 h-80'
                : auraEffect === 'golden_super'
                ? 'bg-amber-400 w-72 h-88'
                : auraEffect === 'crimson_rage'
                ? 'bg-rose-600 w-64 h-80'
                : auraEffect === 'shadow_void'
                ? 'bg-purple-700 w-64 h-80'
                : 'bg-emerald-500 w-64 h-80'
            }`}
          />
        )}

        {/* Vector SVG Anime Character */}
        <svg
          viewBox="0 0 320 440"
          className="relative z-10 w-full h-full max-h-[440px] drop-shadow-2xl overflow-visible transition-all duration-300"
          style={{
            filter:
              auraEffect === 'golden_super'
                ? 'drop-shadow(0 0 18px rgba(245, 158, 11, 0.45))'
                : auraEffect === 'ki_blue'
                ? 'drop-shadow(0 0 18px rgba(6, 182, 212, 0.45))'
                : auraEffect === 'crimson_rage'
                ? 'drop-shadow(0 0 18px rgba(244, 63, 94, 0.5))'
                : auraEffect === 'emerald_focus'
                ? 'drop-shadow(0 0 18px rgba(16, 185, 129, 0.5))'
                : 'drop-shadow(0 8px 24px rgba(0, 0, 0, 0.7))',
          }}
        >
          <defs>
            {/* Skin Cel-Shade Gradient */}
            <linearGradient id="animeSkin" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor={skinTone} />
              <stop offset="100%" stopColor={adjustColor(skinTone, -26)} />
            </linearGradient>

            {/* Hair Cel-Shading */}
            <linearGradient id="animeHair" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor={adjustColor(hairColor, 38)} />
              <stop offset="65%" stopColor={hairColor} />
              <stop offset="100%" stopColor={adjustColor(hairColor, -35)} />
            </linearGradient>

            {/* Anime Eye Glow */}
            <radialGradient id="irisGrad" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#ffffff" />
              <stop offset="35%" stopColor={eyeColor} />
              <stop offset="100%" stopColor={adjustColor(eyeColor, -40)} />
            </radialGradient>

            {/* Outfit Gradient */}
            <linearGradient id="animeOutfit" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor={outfitColor} />
              <stop offset="100%" stopColor={adjustColor(outfitColor, -45)} />
            </linearGradient>

            {/* Golden Energy Particles */}
            <radialGradient id="kiParticle" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="rgba(251, 191, 36, 0.9)" />
              <stop offset="100%" stopColor="rgba(251, 191, 36, 0)" />
            </radialGradient>
          </defs>

          {/* Katana on Back (Diagonally strapped across shoulders) */}
          {(katanaOnBack || accessory === 'katana_back') && (
            <g id="katana-strapped">
              {/* Scabbard / Sheath */}
              <line
                x1={viewAngle === 'back' ? 120 : 130}
                y1="80"
                x2={viewAngle === 'back' ? 205 : 195}
                y2="280"
                stroke="#1e293b"
                strokeWidth="7"
                strokeLinecap="round"
              />
              <line
                x1={viewAngle === 'back' ? 120 : 130}
                y1="80"
                x2={viewAngle === 'back' ? 205 : 195}
                y2="280"
                stroke="#f59e0b"
                strokeWidth="7"
                strokeDasharray="4 14"
              />
              {/* Tsuba (Guard) */}
              <ellipse
                cx={viewAngle === 'back' ? 130 : 140}
                cy="105"
                rx="6"
                ry="4"
                fill="#fbbf24"
                stroke="#0f172a"
                strokeWidth="1.5"
                transform={`rotate(-50 ${viewAngle === 'back' ? 130 : 140} 105)`}
              />
              {/* Hilt / Tsuka */}
              <line
                x1={viewAngle === 'back' ? 130 : 140}
                y1="105"
                x2={viewAngle === 'back' ? 110 : 120}
                y2="60"
                stroke="#b91c1c"
                strokeWidth="5"
                strokeLinecap="square"
              />
              <line
                x1={viewAngle === 'back' ? 130 : 140}
                y1="105"
                x2={viewAngle === 'back' ? 110 : 120}
                y2="60"
                stroke="#ffffff"
                strokeWidth="5"
                strokeDasharray="2 4"
              />
            </g>
          )}

          {/* ======================================================== */}
          {/* VIEW: FRONT (VISTA FRONTAL ANIME) */}
          {/* ======================================================== */}
          {viewAngle === 'front' && (
            <g id="character-front-anime" transform="translate(0, 15)">
              {/* Back Hair Strands */}
              {(hairStyle === 'long_warrior' || hairStyle === 'ponytail') && (
                <path
                  d="M 125 70 C 110 130, 105 190, 120 220 C 135 230, 185 230, 200 220 C 215 190, 210 130, 195 70 Z"
                  fill="url(#animeHair)"
                  stroke="#0f172a"
                  strokeWidth="2"
                />
              )}

              {/* Trapezius & Anime Muscular Neck */}
              <path
                d={`M 144 98 L 176 98 L ${176 + muscleFactor * 14} 122 L ${144 - muscleFactor * 14} 122 Z`}
                fill="url(#animeSkin)"
                stroke="#0f172a"
                strokeWidth="2"
              />
              {/* Neck tendon lines */}
              <line x1="154" y1="100" x2="152" y2="120" stroke="rgba(0,0,0,0.3)" strokeWidth="1.5" />
              <line x1="166" y1="100" x2="168" y2="120" stroke="rgba(0,0,0,0.3)" strokeWidth="1.5" />

              {/* Legs and Anime Boots */}
              {/* Left Leg */}
              <path
                d={
                  currentPose === 'running'
                    ? `M 140 270 Q 120 320 105 385 L 136 385 Q 148 330 155 270 Z`
                    : `M ${160 - waistWidth * 0.45} 270 Q ${145 - legThick * 0.4} 330 135 390 L ${160 - legThick * 0.3} 390 Q ${162} 330 ${160 - waistWidth * 0.1} 270 Z`
                }
                fill={adjustColor(outfitColor, -40)}
                stroke="#0f172a"
                strokeWidth="2.5"
              />
              {/* Right Leg */}
              <path
                d={
                  currentPose === 'running'
                    ? `M 165 270 Q 195 320 215 375 L 184 385 Q 170 330 160 270 Z`
                    : `M ${160 + waistWidth * 0.1} 270 Q ${158} 330 ${160 + legThick * 0.3} 390 L 185 390 Q ${175 + legThick * 0.4} 330 ${160 + waistWidth * 0.45} 270 Z`
                }
                fill={adjustColor(outfitColor, -45)}
                stroke="#0f172a"
                strokeWidth="2.5"
              />

              {/* Anime Combat/Training Sneakers */}
              <rect x={currentPose === 'running' ? 95 : 124} y={currentPose === 'running' ? 382 : 388} width="36" height="16" rx="5" fill="#0f172a" stroke="#38bdf8" strokeWidth="2" />
              <rect x={currentPose === 'running' ? 185 : 160} y={currentPose === 'running' ? 375 : 388} width="36" height="16" rx="5" fill="#0f172a" stroke="#38bdf8" strokeWidth="2" />

              {/* Torso & Core (Math body morphing based on real body fat & muscle) */}
              <path
                d={`
                  M ${160 - shoulderWidth} 122
                  Q ${160 - chestWidth} 165 ${160 - waistWidth} 220
                  Q ${160 - waistWidth - bellyBulge * 0.3} 250 ${160 - waistWidth * 0.8} 275
                  L ${160 + waistWidth * 0.8} 275
                  Q ${160 + waistWidth + bellyBulge * 0.3} 250 ${160 + waistWidth} 220
                  Q ${160 + chestWidth} 165 ${160 + shoulderWidth} 122
                  Z
                `}
                fill={outfit === 'gym_tank' ? 'url(#animeSkin)' : 'url(#animeOutfit)'}
                stroke="#0f172a"
                strokeWidth="2.5"
              />

              {/* Tank Top overlay if gym_tank */}
              {outfit === 'gym_tank' && (
                <path
                  d={`
                    M ${160 - shoulderWidth * 0.65} 122
                    Q 160 148 ${160 + shoulderWidth * 0.65} 122
                    L ${160 + chestWidth * 0.85} 180
                    Q ${160 + waistWidth * 0.9} 225 ${160 + waistWidth * 0.75} 275
                    L ${160 - waistWidth * 0.75} 275
                    Q ${160 - waistWidth * 0.9} 225 ${160 - chestWidth * 0.85} 180
                    Z
                  `}
                  fill="url(#animeOutfit)"
                  stroke="#0f172a"
                  strokeWidth="2"
                />
              )}

              {/* Pecs & Anime Muscle Lines */}
              <g opacity={muscleDefinition}>
                <path d={`M ${160 - chestWidth * 0.75} 158 Q ${160 - chestWidth * 0.35} 176 158 172`} stroke="rgba(0,0,0,0.4)" strokeWidth="2.5" fill="none" />
                <path d={`M ${160 + chestWidth * 0.75} 158 Q ${160 + chestWidth * 0.35} 176 162 172`} stroke="rgba(0,0,0,0.4)" strokeWidth="2.5" fill="none" />
                <line x1="160" y1="135" x2="160" y2="182" stroke="rgba(0,0,0,0.35)" strokeWidth="2" />
              </g>

              {/* Anime 6-Pack Abs (Defined cuts when body fat drops below 18%) */}
              {absOpacity > 0 && (
                <g opacity={absOpacity * muscleDefinition}>
                  <line x1="160" y1="182" x2="160" y2="248" stroke="rgba(0,0,0,0.4)" strokeWidth="2" />
                  <rect x="146" y="186" width="12" height="14" rx="3" fill="none" stroke="rgba(0,0,0,0.35)" strokeWidth="2" />
                  <rect x="162" y="186" width="12" height="14" rx="3" fill="none" stroke="rgba(0,0,0,0.35)" strokeWidth="2" />
                  <rect x="146" y="204" width="12" height="15" rx="3" fill="none" stroke="rgba(0,0,0,0.35)" strokeWidth="2" />
                  <rect x="162" y="204" width="12" height="15" rx="3" fill="none" stroke="rgba(0,0,0,0.35)" strokeWidth="2" />
                  <path d="M 144 242 Q 152 256 160 259 Q 168 256 176 242" fill="none" stroke="rgba(0,0,0,0.4)" strokeWidth="2" />
                </g>
              )}

              {/* Belly Curve (When bodyFat is higher) */}
              {fatFactor > 0.28 && (
                <path
                  d={`M ${160 - waistWidth * 0.65} 225 Q 160 ${225 + bellyBulge * 0.55} ${160 + waistWidth * 0.65} 225`}
                  fill="none"
                  stroke="rgba(0,0,0,0.25)"
                  strokeWidth={2 + fatFactor * 2}
                  strokeLinecap="round"
                />
              )}

              {/* Arms (Pose Dependent) */}
              {/* Left Arm */}
              {currentPose === 'strength' ? (
                <g>
                  {/* Deltoid */}
                  <ellipse cx={160 - shoulderWidth - 4} cy="126" rx={bicepSize * 0.9} ry={bicepSize * 0.9} fill="url(#animeSkin)" stroke="#0f172a" strokeWidth="2" />
                  {/* Bicep */}
                  <path
                    d={`M ${160 - shoulderWidth} 126 Q ${160 - shoulderWidth - 32} 115 ${160 - shoulderWidth - 30} 85 Q ${160 - shoulderWidth - 8} 80 ${160 - shoulderWidth - 4} 126`}
                    fill="url(#animeSkin)"
                    stroke="#0f172a"
                    strokeWidth="2.5"
                  />
                  <rect x={160 - shoulderWidth - 34} y="70" width="20" height="22" rx="7" fill="url(#animeSkin)" stroke="#0f172a" strokeWidth="2" />
                  <ellipse cx={160 - shoulderWidth - 19} cy="95" rx={bicepSize * 0.75} ry={bicepSize * 0.6} fill={adjustColor(skinTone, 16)} opacity="0.4" />
                </g>
              ) : currentPose === 'drawing' ? (
                <g>
                  <path
                    d={`M ${160 - shoulderWidth} 122 Q ${160 - shoulderWidth - 14} 165 140 185 L 148 192 Q ${160 - shoulderWidth + 4} 165 ${160 - shoulderWidth + 10} 122 Z`}
                    fill="url(#animeSkin)"
                    stroke="#0f172a"
                    strokeWidth="2"
                  />
                  {/* Anime Digital Sketchbook */}
                  <rect x="122" y="175" width="46" height="35" rx="5" fill="#0f172a" stroke="#38bdf8" strokeWidth="2" transform="rotate(-10 135 185)" />
                  <circle cx="145" cy="192" r="12" fill="#38bdf8" opacity="0.25" />
                  <line x1="128" y1="184" x2="155" y2="184" stroke="#38bdf8" strokeWidth="1.5" />
                </g>
              ) : (
                <g>
                  <path
                    d={`
                      M ${160 - shoulderWidth} 122
                      Q ${160 - shoulderWidth - bicepSize * 0.8} 165 ${160 - shoulderWidth - 6} 220
                      L ${160 - shoulderWidth + 12} 220
                      Q ${160 - shoulderWidth + bicepSize * 0.4} 165 ${160 - shoulderWidth + 12} 122
                      Z
                    `}
                    fill="url(#animeSkin)"
                    stroke="#0f172a"
                    strokeWidth="2.5"
                  />
                  <ellipse cx={160 - shoulderWidth + 3} cy="228" rx="8" ry="10" fill="url(#animeSkin)" stroke="#0f172a" strokeWidth="2" />
                  {accessory === 'wrist_wraps' && (
                    <rect x={160 - shoulderWidth - 4} y="212" width="15" height="9" rx="2" fill="#ef4444" stroke="#0f172a" strokeWidth="1.5" />
                  )}
                </g>
              )}

              {/* Right Arm */}
              {currentPose === 'strength' ? (
                <g>
                  <ellipse cx={160 + shoulderWidth + 4} cy="126" rx={bicepSize * 0.9} ry={bicepSize * 0.9} fill="url(#animeSkin)" stroke="#0f172a" strokeWidth="2" />
                  <path
                    d={`M ${160 + shoulderWidth} 126 Q ${160 + shoulderWidth + 32} 115 ${160 + shoulderWidth + 30} 85 Q ${160 + shoulderWidth + 8} 80 ${160 + shoulderWidth + 4} 126`}
                    fill="url(#animeSkin)"
                    stroke="#0f172a"
                    strokeWidth="2.5"
                  />
                  <rect x={160 + shoulderWidth + 14} y="70" width="20" height="22" rx="7" fill="url(#animeSkin)" stroke="#0f172a" strokeWidth="2" />
                  <ellipse cx={160 + shoulderWidth + 19} cy="95" rx={bicepSize * 0.75} ry={bicepSize * 0.6} fill={adjustColor(skinTone, 16)} opacity="0.4" />
                </g>
              ) : currentPose === 'drawing' ? (
                <g>
                  <path
                    d={`M ${160 + shoulderWidth} 122 Q ${160 + shoulderWidth + 10} 160 168 180 L 160 186 Q ${160 + shoulderWidth - 4} 160 ${160 + shoulderWidth - 10} 122 Z`}
                    fill="url(#animeSkin)"
                    stroke="#0f172a"
                    strokeWidth="2"
                  />
                  <line x1="164" y1="178" x2="148" y2="186" stroke="#f59e0b" strokeWidth="3" strokeLinecap="round" />
                  <circle cx="147" cy="187" r="3.5" fill="#38bdf8" className="animate-pulse" />
                </g>
              ) : (
                <g>
                  <path
                    d={`
                      M ${160 + shoulderWidth} 122
                      Q ${160 + shoulderWidth + bicepSize * 0.8} 165 ${160 + shoulderWidth + 6} 220
                      L ${160 + shoulderWidth - 12} 220
                      Q ${160 + shoulderWidth - bicepSize * 0.4} 165 ${160 + shoulderWidth - 12} 122
                      Z
                    `}
                    fill="url(#animeSkin)"
                    stroke="#0f172a"
                    strokeWidth="2.5"
                  />
                  <ellipse cx={160 + shoulderWidth - 3} cy="228" rx="8" ry="10" fill="url(#animeSkin)" stroke="#0f172a" strokeWidth="2" />
                  {accessory === 'wrist_wraps' && (
                    <rect x={160 + shoulderWidth - 11} y="212" width="15" height="9" rx="2" fill="#ef4444" stroke="#0f172a" strokeWidth="1.5" />
                  )}
                </g>
              )}

              {/* Anime Head & Face */}
              <g id="anime-head-front">
                {/* Ears */}
                <ellipse cx={160 - faceRoundness - 9} cy="66" rx="5" ry="9" fill="url(#animeSkin)" stroke="#0f172a" strokeWidth="1.5" />
                <ellipse cx={160 + faceRoundness + 9} cy="66" rx="5" ry="9" fill="url(#animeSkin)" stroke="#0f172a" strokeWidth="1.5" />

                {/* Head Shape (Anime Chin) */}
                <path
                  d={
                    faceShape === 'sharp_v'
                      ? `
                        M ${160 - faceRoundness - 6} 55
                        C ${160 - faceRoundness - 8} 25, ${160 + faceRoundness + 8} 25, ${160 + faceRoundness + 6} 55
                        C ${160 + faceRoundness + 6} 76, 168 98, 160 100
                        C 152 98, ${160 - faceRoundness - 6} 76, ${160 - faceRoundness - 6} 55
                        Z
                      `
                      : `
                        M ${160 - faceRoundness - 7} 55
                        C ${160 - faceRoundness - 9} 25, ${160 + faceRoundness + 9} 25, ${160 + faceRoundness + 7} 55
                        C ${160 + faceRoundness + 7} 78, 172 96, 160 98
                        C 148 96, ${160 - faceRoundness - 7} 78, ${160 - faceRoundness - 7} 55
                        Z
                      `
                  }
                  fill="url(#animeSkin)"
                  stroke="#0f172a"
                  strokeWidth="2.5"
                />

                {/* Anime EYES (High Detail with iris gradient & highlights) */}
                <g id="anime-eyes">
                  {/* Left Eye */}
                  <g>
                    {/* Upper Eyelash line */}
                    <path d="M 141 57 Q 148 52 155 56" stroke="#0f172a" strokeWidth="3.2" strokeLinecap="round" fill="none" />
                    {/* Eye Iris with radial gradient */}
                    <ellipse cx="148" cy="62" rx="5" ry="6" fill="url(#irisGrad)" />
                    <ellipse cx="148" cy="62" rx="2.5" ry="3.5" fill="#0f172a" />
                    {/* Anime Catchlights / Glints */}
                    <circle cx="149.5" cy="59.5" r="2" fill="#ffffff" />
                    <circle cx="146.5" cy="64" r="1.1" fill="#ffffff" />
                    {/* Lower eyelash mark */}
                    <line x1="145" y1="68" x2="152" y2="68" stroke="#0f172a" strokeWidth="1.5" />
                  </g>

                  {/* Right Eye */}
                  <g>
                    <path d="M 165 56 Q 172 52 179 57" stroke="#0f172a" strokeWidth="3.2" strokeLinecap="round" fill="none" />
                    <ellipse cx="172" cy="62" rx="5" ry="6" fill="url(#irisGrad)" />
                    <ellipse cx="172" cy="62" rx="2.5" ry="3.5" fill="#0f172a" />
                    <circle cx="173.5" cy="59.5" r="2" fill="#ffffff" />
                    <circle cx="170.5" cy="64" r="1.1" fill="#ffffff" />
                    <line x1="168" y1="68" x2="175" y2="68" stroke="#0f172a" strokeWidth="1.5" />
                  </g>

                  {/* Eyebrows */}
                  <path d="M 139 50 L 155 53" stroke="#0f172a" strokeWidth="3" strokeLinecap="round" />
                  <path d="M 181 50 L 165 53" stroke="#0f172a" strokeWidth="3" strokeLinecap="round" />
                </g>

                {/* Anime Nose & Mouth */}
                <path d="M 160 67 L 158 73 L 161 73" stroke="#0f172a" strokeWidth="2" fill="none" strokeLinecap="round" />
                <path d="M 154 81 Q 160 84 167 81" stroke="#0f172a" strokeWidth="2.5" fill="none" strokeLinecap="round" />

                {/* Facial Hair */}
                {facialHair !== 'none' && (
                  <g>
                    {facialHair === 'stubble' && (
                      <path d="M 148 83 Q 160 93 172 83" stroke={facialHairColor} strokeWidth="3" strokeDasharray="2 2" fill="none" />
                    )}
                    {facialHair === 'beard_short' && (
                      <path d="M 144 76 Q 160 98 176 76 Q 160 93 144 76 Z" fill={facialHairColor} opacity="0.9" />
                    )}
                    {facialHair === 'goatee' && (
                      <polygon points="156,83 164,83 161,96 159,96" fill={facialHairColor} />
                    )}
                  </g>
                )}

                {/* Anime Hair Styles */}
                <g id="anime-hair-front">
                  {hairStyle === 'anime_messy' && (
                    <path
                      d="M 130 52 L 120 32 L 136 34 L 140 14 L 158 24 L 168 10 L 178 26 L 194 16 L 192 40 L 202 46 L 188 58 Q 160 40 130 52 Z"
                      fill="url(#animeHair)"
                      stroke="#0f172a"
                      strokeWidth="2.5"
                    />
                  )}
                  {hairStyle === 'supersaiyan' && (
                    <g>
                      <path
                        d="M 132 48 L 115 15 L 138 24 L 142 -5 L 160 12 L 175 -8 L 180 20 L 205 10 L 190 48 Q 160 38 132 48 Z"
                        fill="url(#animeHair)"
                        stroke="#0f172a"
                        strokeWidth="2.5"
                      />
                      {/* Inner gold glow lines */}
                      <path d="M 142 8 L 155 24 M 172 6 L 165 24" stroke="#ffffff" strokeWidth="1.5" opacity="0.6" />
                    </g>
                  )}
                  {hairStyle === 'short_spiky' && (
                    <path
                      d="M 134 50 L 130 28 L 142 34 L 150 16 L 160 30 L 172 14 L 178 32 L 190 26 L 186 50 Q 160 40 134 50 Z"
                      fill="url(#animeHair)"
                      stroke="#0f172a"
                      strokeWidth="2.2"
                    />
                  )}
                  {hairStyle === 'undercut' && (
                    <g>
                      <path d="M 135 52 Q 138 26 160 24 Q 182 26 185 52 Z" fill="url(#animeHair)" stroke="#0f172a" strokeWidth="2.2" />
                      <path d="M 133 46 L 138 56 L 133 58 Z" fill="#1e293b" />
                      <path d="M 187 46 L 182 56 L 187 58 Z" fill="#1e293b" />
                    </g>
                  )}
                  {hairStyle === 'buzz' && (
                    <path d="M 136 50 Q 160 30 184 50 Z" fill={hairColor} opacity="0.85" />
                  )}
                  {hairStyle === 'long_warrior' && (
                    <path
                      d="M 133 50 L 126 28 L 140 26 L 152 14 L 164 24 L 180 18 L 186 50 Q 160 40 133 50 Z"
                      fill="url(#animeHair)"
                      stroke="#0f172a"
                      strokeWidth="2.2"
                    />
                  )}
                  {hairStyle === 'ponytail' && (
                    <g>
                      <path d="M 135 50 Q 160 28 185 50 Z" fill="url(#animeHair)" stroke="#0f172a" strokeWidth="2.2" />
                      <path d="M 175 30 Q 205 10 215 35 Q 200 45 178 38 Z" fill="url(#animeHair)" stroke="#0f172a" strokeWidth="2" />
                    </g>
                  )}
                </g>

                {/* Head Accessories */}
                {accessory === 'headband' && (
                  <g>
                    <path d="M 134 42 Q 160 46 186 42 L 186 48 Q 160 52 134 48 Z" fill="#ef4444" stroke="#0f172a" strokeWidth="1.5" />
                    <rect x="154" y="43" width="12" height="6" rx="1.5" fill="#cbd5e1" stroke="#0f172a" strokeWidth="1" />
                  </g>
                )}
                {accessory === 'scouter' && (
                  <g>
                    <rect x="138" y="55" width="17" height="13" rx="3" fill="#22c55e" opacity="0.8" stroke="#16a34a" strokeWidth="1.5" />
                    <line x1="138" y1="61" x2="128" y2="64" stroke="#0f172a" strokeWidth="2" />
                  </g>
                )}
                {accessory === 'fox_mask' && (
                  <g transform="translate(168, 30) scale(0.6)">
                    <polygon points="10,0 20,25 0,25" fill="#f8fafc" stroke="#dc2626" strokeWidth="2" />
                    <polygon points="30,0 40,25 20,25" fill="#f8fafc" stroke="#dc2626" strokeWidth="2" />
                    <ellipse cx="20" cy="30" rx="18" ry="14" fill="#f8fafc" stroke="#0f172a" strokeWidth="2" />
                    <path d="M 12 28 Q 16 32 20 28 M 20 28 Q 24 32 28 28" stroke="#dc2626" strokeWidth="2" fill="none" />
                  </g>
                )}
              </g>
            </g>
          )}

          {/* ======================================================== */}
          {/* VIEW: SIDE (VISTA LATERAL / PERFIL ANIME) */}
          {/* ======================================================== */}
          {viewAngle === 'side' && (
            <g id="character-side-anime" transform="translate(0, 15)">
              {/* Back Leg */}
              <path d="M 152 270 Q 140 330 135 390 L 160 390 Q 165 330 168 270 Z" fill={adjustColor(outfitColor, -45)} stroke="#0f172a" strokeWidth="2" />
              <rect x="125" y="388" width="38" height="15" rx="5" fill="#0f172a" stroke="#38bdf8" strokeWidth="2" />

              {/* Torso Profile (Belly protrudes or flattens directly with fat%) */}
              <path
                d={`
                  M 140 115
                  Q 132 170 138 275
                  L 172 275
                  Q ${176 + bellyBulge * 0.9} 225 ${174 + muscleFactor * 12} 165
                  Q ${178 + muscleFactor * 14} 145 168 115
                  Z
                `}
                fill={outfit === 'gym_tank' ? 'url(#animeSkin)' : 'url(#animeOutfit)'}
                stroke="#0f172a"
                strokeWidth="2.5"
              />

              {/* Front Leg */}
              <path d="M 160 270 Q 162 330 155 390 L 185 390 Q 188 330 180 270 Z" fill={adjustColor(outfitColor, -35)} stroke="#0f172a" strokeWidth="2" />
              <rect x="150" y="388" width="38" height="15" rx="5" fill="#0f172a" stroke="#38bdf8" strokeWidth="2" />

              {/* Arm in Side View */}
              <path
                d={`
                  M 152 120
                  Q ${145 - bicepSize * 0.5} 165 148 220
                  L 165 220
                  Q ${168 + bicepSize * 0.5} 165 166 120
                  Z
                `}
                fill="url(#animeSkin)"
                stroke="#0f172a"
                strokeWidth="2.5"
              />
              <ellipse cx="156" cy="228" rx="8" ry="10" fill="url(#animeSkin)" stroke="#0f172a" strokeWidth="2" />

              {/* Anime Head Profile */}
              <g id="anime-head-side">
                <path
                  d="M 140 50 Q 142 24 165 24 Q 182 26 182 52 L 189 63 L 181 65 L 183 75 Q 166 96 148 88 Z"
                  fill="url(#animeSkin)"
                  stroke="#0f172a"
                  strokeWidth="2.2"
                />
                <polygon points="172,56 179,53 178,61" fill={eyeColor} stroke="#0f172a" strokeWidth="1" />
                <circle cx="175" cy="56" r="1.2" fill="#ffffff" />
                <ellipse cx="150" cy="65" rx="5" ry="9" fill="url(#animeSkin)" stroke="#0f172a" strokeWidth="1.5" />

                {/* Hair Profile */}
                <path d="M 136 52 Q 138 20 165 18 L 176 13 L 180 28 L 190 35 L 178 50 Z" fill="url(#animeHair)" stroke="#0f172a" strokeWidth="2.2" />
              </g>
            </g>
          )}

          {/* ======================================================== */}
          {/* VIEW: BACK (VISTA TRASERA ANIME - DORSALES EN V) */}
          {/* ======================================================== */}
          {viewAngle === 'back' && (
            <g id="character-back-anime" transform="translate(0, 15)">
              {/* Back Hair */}
              <path
                d="M 135 45 C 132 15, 188 15, 185 45 C 190 75, 192 100, 160 98 C 128 100, 130 75, 135 45 Z"
                fill="url(#animeHair)"
                stroke="#0f172a"
                strokeWidth="2.2"
              />

              {/* Legs */}
              <path
                d={`M ${160 - waistWidth * 0.45} 270 Q 145 330 135 390 L 160 390 Q 162 330 ${160 - waistWidth * 0.1} 270 Z`}
                fill={adjustColor(outfitColor, -40)}
                stroke="#0f172a"
                strokeWidth="2.5"
              />
              <path
                d={`M ${160 + waistWidth * 0.1} 270 Q 158 330 160 390 L 185 390 Q 175 330 ${160 + waistWidth * 0.45} 270 Z`}
                fill={adjustColor(outfitColor, -45)}
                stroke="#0f172a"
                strokeWidth="2.5"
              />
              <rect x={124} y={388} width="36" height="15" rx="5" fill="#0f172a" stroke="#38bdf8" strokeWidth="2" />
              <rect x={160} y={388} width="36" height="15" rx="5" fill="#0f172a" stroke="#38bdf8" strokeWidth="2" />

              {/* Back Torso (Anime V-Taper Lats) */}
              <path
                d={`
                  M ${160 - shoulderWidth} 122
                  Q ${160 - chestWidth} 165 ${160 - waistWidth} 220
                  Q ${160 - waistWidth} 250 ${160 - waistWidth * 0.8} 275
                  L ${160 + waistWidth * 0.8} 275
                  Q ${160 + waistWidth} 250 ${160 + waistWidth} 220
                  Q ${160 + chestWidth} 165 ${160 + shoulderWidth} 122
                  Z
                `}
                fill={outfit === 'gym_tank' ? 'url(#animeSkin)' : 'url(#animeOutfit)'}
                stroke="#0f172a"
                strokeWidth="2.5"
              />

              {/* Tank top racer back */}
              {outfit === 'gym_tank' && (
                <path
                  d={`
                    M 152 122 L 168 122
                    L 165 160
                    L ${160 + waistWidth * 0.8} 275
                    L ${160 - waistWidth * 0.8} 275
                    L 155 160
                    Z
                  `}
                  fill="url(#animeOutfit)"
                  stroke="#0f172a"
                  strokeWidth="2"
                />
              )}

              {/* Lats and spine muscle definition */}
              <g opacity={muscleDefinition}>
                <line x1="160" y1="122" x2="160" y2="235" stroke="rgba(0,0,0,0.35)" strokeWidth="2" />
                <path d={`M ${160 - shoulderWidth} 128 Q ${160 - shoulderWidth * 0.6} 142 156 140`} fill="none" stroke="rgba(0,0,0,0.3)" strokeWidth="2" />
                <path d={`M ${160 + shoulderWidth} 128 Q ${160 + shoulderWidth * 0.6} 142 164 140`} fill="none" stroke="rgba(0,0,0,0.3)" strokeWidth="2" />
              </g>

              {/* Arms Back */}
              <path
                d={`
                  M ${160 - shoulderWidth} 122
                  Q ${160 - shoulderWidth - bicepSize * 0.8} 165 ${160 - shoulderWidth - 6} 220
                  L ${160 - shoulderWidth + 12} 220
                  Q ${160 - shoulderWidth + bicepSize * 0.4} 165 ${160 - shoulderWidth + 12} 122
                  Z
                `}
                fill="url(#animeSkin)"
                stroke="#0f172a"
                strokeWidth="2.5"
              />
              <path
                d={`
                  M ${160 + shoulderWidth} 122
                  Q ${160 + shoulderWidth + bicepSize * 0.8} 165 ${160 + shoulderWidth + 6} 220
                  L ${160 + shoulderWidth - 12} 220
                  Q ${160 + shoulderWidth - bicepSize * 0.4} 165 ${160 + shoulderWidth - 12} 122
                  Z
                `}
                fill="url(#animeSkin)"
                stroke="#0f172a"
                strokeWidth="2.5"
              />
            </g>
          )}
        </svg>

        {/* Level & Rank Badge */}
        <div className="absolute top-3 right-3 z-20 flex flex-col items-end">
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-slate-900/90 border border-cyan-500/40 backdrop-blur-md shadow-lg shadow-cyan-950/40">
            <span className="text-[10px] font-bold text-cyan-400 tracking-wider">NIVEL</span>
            <span className="text-sm font-black text-white font-mono-num">{level}</span>
          </div>
          <span className="text-[10px] text-slate-400 mt-1 font-medium bg-black/60 px-2 py-0.5 rounded">
            {bodyFatPercent <= 14
              ? 'Atleta Definido'
              : bodyFatPercent <= 20
              ? 'En Forma'
              : bodyFatPercent <= 26
              ? 'En Progreso'
              : 'Inicio del Arco'}
          </span>
        </div>

        {/* Real Physics Telemetry Overlay */}
        <div className="absolute bottom-3 left-3 z-20 bg-slate-950/80 border border-slate-800/80 backdrop-blur-md rounded-lg p-2 text-xs">
          <div className="flex items-center gap-2 text-slate-400">
            <span>
              Peso: <strong className="text-white font-mono-num">{weightKg} kg</strong>
            </span>
            <span>·</span>
            <span>
              Grasa: <strong className="text-cyan-400 font-mono-num">{bodyFatPercent}%</strong>
            </span>
          </div>
        </div>
      </div>

      {/* Interactive Toolbar for Rotation & Poses */}
      {interactive && (
        <div className="w-full mt-3 flex flex-col gap-2">
          {/* Angle view selector */}
          <div className="flex items-center justify-between p-1 bg-slate-900/90 border border-slate-800 rounded-xl">
            <span className="text-[11px] font-semibold text-slate-400 px-2 uppercase tracking-wider">Vista</span>
            <div className="flex items-center gap-1">
              {(['front', 'side', 'back'] as ViewAngle[]).map((angle) => (
                <button
                  key={angle}
                  onClick={() => onViewChange?.(angle)}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                    viewAngle === angle
                      ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                      : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
                  }`}
                >
                  {angle === 'front' ? 'Frente' : angle === 'side' ? 'Perfil' : 'Espalda'}
                </button>
              ))}
            </div>
          </div>

          {/* Pose Selector */}
          <div className="flex items-center justify-between p-1 bg-slate-900/90 border border-slate-800 rounded-xl overflow-x-auto">
            <span className="text-[11px] font-semibold text-slate-400 px-2 uppercase tracking-wider whitespace-nowrap">Pose</span>
            <div className="flex items-center gap-1">
              {[
                { id: 'idle', label: 'Reposo' },
                { id: 'strength', label: 'Fuerza' },
                { id: 'running', label: 'Carrera' },
                { id: 'drawing', label: 'Dibujo' },
              ].map((p) => (
                <button
                  key={p.id}
                  onClick={() => onPoseChange?.(p.id as CharacterPose)}
                  className={`px-2.5 py-1 text-xs font-medium rounded-lg whitespace-nowrap transition-all ${
                    currentPose === p.id
                      ? 'bg-blue-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
                  }`}
                >
                  {p.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

function adjustColor(hex: string, amount: number): string {
  try {
    let cleanHex = hex.replace('#', '');
    if (cleanHex.length === 3) {
      cleanHex = cleanHex.split('').map((c) => c + c).join('');
    }
    const num = parseInt(cleanHex, 16);
    let r = (num >> 16) + amount;
    let g = ((num >> 8) & 0x00ff) + amount;
    let b = (num & 0x0000ff) + amount;
    r = Math.min(255, Math.max(0, r));
    g = Math.min(255, Math.max(0, g));
    b = Math.min(255, Math.max(0, b));
    return `#${((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1)}`;
  } catch {
    return hex;
  }
}
