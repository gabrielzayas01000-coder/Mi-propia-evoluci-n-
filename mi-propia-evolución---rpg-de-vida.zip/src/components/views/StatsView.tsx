import React, { useState } from 'react';
import {
  PlayerProfile,
  BodyMeasurement,
  HabitLog,
  HabitDefinition,
  AttributeKey,
  AttributeState,
  Achievement,
} from '../../types/game';
import {
  Scale,
  Activity,
  Flame,
  Award,
  TrendingDown,
  TrendingUp,
  Dumbbell,
  Footprints,
  Palette,
  ShieldCheck,
  Plus,
} from 'lucide-react';

interface StatsViewProps {
  profile: PlayerProfile;
  measurements: BodyMeasurement[];
  logs: HabitLog[];
  habits: HabitDefinition[];
  attributes: Record<AttributeKey, AttributeState>;
  achievements: Achievement[];
  currentStreak: number;
  bestStreak: number;
  onOpenMeasurementModal: () => void;
}

export const StatsView: React.FC<StatsViewProps> = ({
  profile,
  measurements,
  logs,
  habits,
  attributes,
  achievements,
  currentStreak,
  bestStreak,
  onOpenMeasurementModal,
}) => {
  const [selectedMetric, setSelectedMetric] = useState<'weight' | 'fat' | 'muscle'>('weight');

  // Sorted measurements ascending by date for charts
  const sortedMeasurements = [...measurements].sort(
    (a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()
  );

  const firstMeas = sortedMeasurements[0] || null;
  const latestMeas = sortedMeasurements[sortedMeasurements.length - 1] || null;

  // Real deltas
  const weightDelta = firstMeas && latestMeas ? parseFloat((latestMeas.weightKg - firstMeas.weightKg).toFixed(1)) : 0;
  const fatDelta = firstMeas && latestMeas ? parseFloat((latestMeas.bodyFatPercent - firstMeas.bodyFatPercent).toFixed(1)) : 0;
  const muscleDelta = firstMeas?.muscleMassKg && latestMeas?.muscleMassKg
    ? parseFloat((latestMeas.muscleMassKg - firstMeas.muscleMassKg).toFixed(1))
    : 0;

  // Real Habit stats
  const completedLogs = logs.filter((l) => l.status === 'completed');
  const gymSessionsTotal = completedLogs.filter((l) => l.habitId === 'gym').length;
  const runSessionsTotal = completedLogs.filter((l) => l.habitId === 'running').length;
  const totalKmRan = completedLogs
    .filter((l) => l.habitId === 'running' && l.metricValue)
    .reduce((sum, l) => sum + (l.metricValue || 0), 0);
  const drawSessionsTotal = completedLogs.filter((l) => l.habitId === 'drawing').length;
  const totalDrawMins = completedLogs
    .filter((l) => l.habitId === 'drawing' && l.metricValue)
    .reduce((sum, l) => sum + (l.metricValue || 0), 0);

  const unlockedAchievementsCount = achievements.filter((a) => a.isUnlocked).length;

  // Chart Generation Math
  const chartWidth = 320;
  const chartHeight = 160;
  const padding = 28;

  const getMetricData = () => {
    return sortedMeasurements.map((m) => {
      let val = m.weightKg;
      if (selectedMetric === 'fat') val = m.bodyFatPercent;
      if (selectedMetric === 'muscle') val = m.muscleMassKg || 0;
      return { date: m.date, value: val };
    });
  };

  const chartData = getMetricData();
  const values = chartData.map((d) => d.value);
  const minVal = Math.min(...values, selectedMetric === 'fat' ? 10 : 60);
  const maxVal = Math.max(...values, selectedMetric === 'fat' ? 30 : 95);
  const range = Math.max(1, maxVal - minVal);

  const points = chartData.map((d, idx) => {
    const x = padding + (idx / Math.max(1, chartData.length - 1)) * (chartWidth - padding * 2);
    const y = chartHeight - padding - ((d.value - minVal) / range) * (chartHeight - padding * 2);
    return { x, y, date: d.date, value: d.value };
  });

  const pathD = points.length > 0
    ? `M ${points.map((p) => `${p.x},${p.y}`).join(' L ')}`
    : '';

  return (
    <div className="space-y-4 pb-20">
      {/* Title Bar */}
      <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-xl flex items-center justify-between">
        <div>
          <h1 className="text-lg font-black text-white font-rpg tracking-wide">
            Estadísticas y Evolución
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Distinguiendo datos físicos reales vs estadísticas del videojuego
          </p>
        </div>

        <button
          onClick={onOpenMeasurementModal}
          className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold shadow-md shadow-cyan-500/20 active:scale-95 transition"
        >
          <Plus className="w-4 h-4" />
          <span>Nueva Medición</span>
        </button>
      </div>

      {/* SECTION 1: MEDICIONES FÍSICAS REALES */}
      <div className="p-4 rounded-2xl bg-slate-900/90 border border-cyan-500/30 shadow-xl">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Scale className="w-5 h-5 text-cyan-400" />
            <h2 className="text-sm font-black text-white font-rpg uppercase tracking-wider">
              Evolución Corporal Real
            </h2>
          </div>
          <span className="text-[10px] text-cyan-300 font-semibold px-2 py-0.5 rounded bg-cyan-950/80 border border-cyan-800/60">
            Medición Manual Real
          </span>
        </div>

        {/* Comparison: Antes vs Ahora */}
        {firstMeas && latestMeas && (
          <div className="grid grid-cols-3 gap-2 p-3 rounded-xl bg-slate-950/80 border border-slate-800 mb-4 text-center">
            {/* Peso */}
            <div className="space-y-0.5">
              <span className="text-[10px] font-semibold text-slate-400 block uppercase">Peso</span>
              <span className="text-base font-black text-white font-mono-num">
                {latestMeas.weightKg} kg
              </span>
              <span className={`text-[10px] font-bold block ${weightDelta <= 0 ? 'text-emerald-400' : 'text-amber-400'}`}>
                {weightDelta > 0 ? `+${weightDelta}` : weightDelta} kg
              </span>
            </div>

            {/* % Grasa */}
            <div className="space-y-0.5 border-x border-slate-800">
              <span className="text-[10px] font-semibold text-slate-400 block uppercase">% Grasa</span>
              <span className="text-base font-black text-cyan-400 font-mono-num">
                {latestMeas.bodyFatPercent}%
              </span>
              <span className={`text-[10px] font-bold block ${fatDelta <= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                {fatDelta > 0 ? `+${fatDelta}` : fatDelta}%
              </span>
            </div>

            {/* Masa Muscular */}
            <div className="space-y-0.5">
              <span className="text-[10px] font-semibold text-slate-400 block uppercase">Músculo</span>
              <span className="text-base font-black text-blue-400 font-mono-num">
                {latestMeas.muscleMassKg || profile.currentMuscleMassKg || '--'} kg
              </span>
              <span className="text-[10px] font-bold text-emerald-400 block">
                {muscleDelta > 0 ? `+${muscleDelta} kg` : 'Constante'}
              </span>
            </div>
          </div>
        )}

        {/* Metric Selector Tabs */}
        <div className="flex items-center gap-1 p-1 bg-slate-950 rounded-xl border border-slate-800 mb-3">
          <button
            onClick={() => setSelectedMetric('weight')}
            className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition ${
              selectedMetric === 'weight'
                ? 'bg-cyan-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Peso Corporal
          </button>
          <button
            onClick={() => setSelectedMetric('fat')}
            className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition ${
              selectedMetric === 'fat'
                ? 'bg-cyan-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            % Grasa
          </button>
          <button
            onClick={() => setSelectedMetric('muscle')}
            className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition ${
              selectedMetric === 'muscle'
                ? 'bg-cyan-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Masa Muscular
          </button>
        </div>

        {/* SVG Evolution Graph */}
        <div className="relative w-full rounded-xl bg-slate-950/90 border border-slate-800 p-2 overflow-hidden">
          <svg viewBox={`0 0 ${chartWidth} ${chartHeight}`} className="w-full h-44 overflow-visible">
            {/* Grid lines */}
            <line x1={padding} y1={padding} x2={chartWidth - padding} y2={padding} stroke="#1e293b" strokeDasharray="3 3" />
            <line x1={padding} y1={chartHeight / 2} x2={chartWidth - padding} y2={chartHeight / 2} stroke="#1e293b" strokeDasharray="3 3" />
            <line x1={padding} y1={chartHeight - padding} x2={chartWidth - padding} y2={chartHeight - padding} stroke="#1e293b" />

            {/* Line Path */}
            {points.length > 1 && (
              <path
                d={pathD}
                fill="none"
                stroke={selectedMetric === 'fat' ? '#06b6d4' : selectedMetric === 'muscle' ? '#3b82f6' : '#22c55e'}
                strokeWidth="3"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            )}

            {/* Points & Labels */}
            {points.map((p, i) => (
              <g key={i}>
                <circle
                  cx={p.x}
                  cy={p.y}
                  r="5"
                  fill="#080c14"
                  stroke={selectedMetric === 'fat' ? '#06b6d4' : '#22c55e'}
                  strokeWidth="2.5"
                />
                {/* Value text above */}
                <text
                  x={p.x}
                  y={p.y - 8}
                  textAnchor="middle"
                  fill="#f1f5f9"
                  fontSize="10"
                  fontFamily="Space Mono"
                  fontWeight="bold"
                >
                  {p.value}
                </text>
                {/* Date text below */}
                <text
                  x={p.x}
                  y={chartHeight - 8}
                  textAnchor="middle"
                  fill="#64748b"
                  fontSize="8"
                  fontFamily="Space Mono"
                >
                  {p.date.slice(5)}
                </text>
              </g>
            ))}
          </svg>
        </div>

        {/* Measurements History Table */}
        <div className="mt-3">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-2">
            Historial de Mediciones Registradas
          </span>
          <div className="space-y-1.5 max-h-40 overflow-y-auto pr-1">
            {sortedMeasurements.slice().reverse().map((m) => (
              <div
                key={m.id}
                className="p-2 rounded-lg bg-slate-950/60 border border-slate-800/80 flex items-center justify-between text-xs"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono-num font-bold text-white">{m.date}</span>
                    <span className="text-slate-400">·</span>
                    <span className="text-slate-300 font-mono-num">{m.weightKg} kg</span>
                    <span className="text-slate-400">·</span>
                    <span className="text-cyan-400 font-mono-num">{m.bodyFatPercent}% grasa</span>
                  </div>
                  {m.notes && <p className="text-[10px] text-slate-500 italic mt-0.5">"{m.notes}"</p>}
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-slate-400 block">IMC: {m.calculatedImc}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* SECTION 2: ESTADÍSTICAS REALES DE ACTIVIDADES */}
      <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-xl">
        <h2 className="text-sm font-black text-white font-rpg uppercase tracking-wider mb-3">
          Totales de Actividad Real
        </h2>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800">
            <div className="flex items-center gap-1.5 text-xs text-blue-400 font-semibold mb-1">
              <Dumbbell className="w-4 h-4" /> Gimnasio
            </div>
            <span className="text-xl font-black text-white font-mono-num">{gymSessionsTotal}</span>
            <span className="text-[10px] text-slate-400 block mt-0.5">sesiones completadas</span>
          </div>

          <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800">
            <div className="flex items-center gap-1.5 text-xs text-cyan-400 font-semibold mb-1">
              <Footprints className="w-4 h-4" /> Carrera
            </div>
            <span className="text-xl font-black text-white font-mono-num">{totalKmRan.toFixed(1)}</span>
            <span className="text-[10px] text-slate-400 block mt-0.5">km en {runSessionsTotal} carreras</span>
          </div>

          <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800">
            <div className="flex items-center gap-1.5 text-xs text-amber-400 font-semibold mb-1">
              <Palette className="w-4 h-4" /> Dibujo
            </div>
            <span className="text-xl font-black text-white font-mono-num">{drawSessionsTotal}</span>
            <span className="text-[10px] text-slate-400 block mt-0.5">{totalDrawMins} mins dedicados</span>
          </div>

          <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800">
            <div className="flex items-center gap-1.5 text-xs text-amber-500 font-semibold mb-1">
              <Flame className="w-4 h-4" /> Racha Récord
            </div>
            <span className="text-xl font-black text-white font-mono-num">{bestStreak}</span>
            <span className="text-[10px] text-slate-400 block mt-0.5">días consecutivos</span>
          </div>
        </div>
      </div>

      {/* SECTION 3: ESTADÍSTICAS RPG (JUEGO) */}
      <div className="p-4 rounded-2xl bg-slate-900/90 border border-indigo-500/30 shadow-xl">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Award className="w-5 h-5 text-indigo-400" />
            <h2 className="text-sm font-black text-white font-rpg uppercase tracking-wider">
              Estadísticas RPG (Juego)
            </h2>
          </div>
          <span className="text-[10px] text-indigo-300 font-semibold px-2 py-0.5 rounded bg-indigo-950/80 border border-indigo-800/60">
            Sistema de Progresión
          </span>
        </div>

        <div className="grid grid-cols-3 gap-2 text-center mb-3">
          <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800">
            <span className="text-[10px] text-slate-400 font-semibold uppercase block">Nivel Actual</span>
            <span className="text-lg font-black text-cyan-300 font-mono-num">{profile.level}</span>
          </div>
          <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800">
            <span className="text-[10px] text-slate-400 font-semibold uppercase block">XP Acumulado</span>
            <span className="text-lg font-black text-indigo-300 font-mono-num">{profile.totalXP}</span>
          </div>
          <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800">
            <span className="text-[10px] text-slate-400 font-semibold uppercase block">Logros</span>
            <span className="text-lg font-black text-amber-300 font-mono-num">
              {unlockedAchievementsCount} / {achievements.length}
            </span>
          </div>
        </div>

        {/* Detailed Attribute Breakdown */}
        <div className="space-y-2 mt-4">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
            Fuentes de Experiencia por Atributo
          </span>

          {([
            { key: 'strength', name: 'Fuerza', state: attributes.strength, desc: 'Sesiones de gimnasio y levantamiento de pesas' },
            { key: 'endurance', name: 'Resistencia', state: attributes.endurance, desc: 'Sesiones de carrera y cardio' },
            { key: 'creativity', name: 'Creatividad', state: attributes.creativity, desc: 'Sesiones de dibujo y bocetado' },
            { key: 'discipline', name: 'Disciplina', state: attributes.discipline, desc: 'Rachas activas y constancia diaria' },
            { key: 'vitality', name: 'Vitalidad', state: attributes.vitality, desc: 'Hábitos saludables y autodominio' },
          ] as { key: AttributeKey; name: string; state: AttributeState; desc: string }[]).map((attr) => (
            <div key={attr.key} className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800">
              <div className="flex items-center justify-between text-xs font-semibold">
                <span className="text-white">{attr.name}</span>
                <span className="text-cyan-400 font-mono-num font-bold">Nv. {attr.state.level} ({attr.state.totalXP} XP)</span>
              </div>
              <p className="text-[10px] text-slate-400 mt-0.5">{attr.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
