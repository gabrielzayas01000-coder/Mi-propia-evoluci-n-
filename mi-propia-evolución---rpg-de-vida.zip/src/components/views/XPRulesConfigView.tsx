import React, { useState } from 'react';
import { HabitDefinition, AttributeKey } from '../../types/game';
import { soundEffects } from '../../utils/soundEffects';
import {
  Sliders,
  Plus,
  Trash2,
  RotateCcw,
  Check,
  Sparkles,
  Zap,
  Target,
  Flame,
  Award,
  HelpCircle,
} from 'lucide-react';

interface XPRulesConfigViewProps {
  habits: HabitDefinition[];
  onUpdateHabits: (updatedHabits: HabitDefinition[]) => void;
  onResetHabitsToDefault: () => void;
}

export const XPRulesConfigView: React.FC<XPRulesConfigViewProps> = ({
  habits,
  onUpdateHabits,
  onResetHabitsToDefault,
}) => {
  const [localHabits, setLocalHabits] = useState<HabitDefinition[]>(habits);
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [showNewHabitModal, setShowNewHabitModal] = useState(false);

  // New Custom Habit Form State
  const [newHabitName, setNewHabitName] = useState('');
  const [newHabitCategory, setNewHabitCategory] = useState('Desarrollo Personal');
  const [newHabitDesc, setNewHabitDesc] = useState('');
  const [newHabitBaseXP, setNewHabitBaseXP] = useState('60');
  const [newHabitPrimaryAttr, setNewHabitPrimaryAttr] = useState<AttributeKey>('creativity');
  const [newHabitSecondaryAttr, setNewHabitSecondaryAttr] = useState<AttributeKey | 'none'>('discipline');
  const [newHabitPrimaryShare, setNewHabitPrimaryShare] = useState('80');
  const [newHabitGoal, setNewHabitGoal] = useState('5');
  const [newHabitMetricLabel, setNewHabitMetricLabel] = useState('Tiempo');
  const [newHabitMetricUnit, setNewHabitMetricUnit] = useState('minutos');
  const [newHabitMetricBonus, setNewHabitMetricBonus] = useState('1');

  const attributeOptions: { key: AttributeKey; name: string; color: string }[] = [
    { key: 'strength', name: 'Fuerza', color: 'text-blue-400' },
    { key: 'endurance', name: 'Resistencia', color: 'text-cyan-400' },
    { key: 'creativity', name: 'Creatividad', color: 'text-amber-400' },
    { key: 'discipline', name: 'Disciplina', color: 'text-rose-400' },
    { key: 'vitality', name: 'Vitalidad', color: 'text-emerald-400' },
  ];

  const handleHabitFieldChange = <K extends keyof HabitDefinition>(
    habitId: string,
    field: K,
    value: HabitDefinition[K]
  ) => {
    const updated = localHabits.map((h) => {
      if (h.id === habitId) {
        const next = { ...h, [field]: value };
        // Keep shares complementary if primary share changed
        if (field === 'primaryAttrShare' && typeof value === 'number') {
          next.secondaryAttrShare = Math.max(0, 100 - value);
        }
        return next;
      }
      return h;
    });
    setLocalHabits(updated);
  };

  const handleSaveAllRules = () => {
    soundEffects.playClick();
    onUpdateHabits(localHabits);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  const handleDeleteHabit = (habitId: string) => {
    if (window.confirm('¿Seguro que deseas eliminar esta actividad de la lista de reglas?')) {
      const updated = localHabits.filter((h) => h.id !== habitId);
      setLocalHabits(updated);
      onUpdateHabits(updated);
    }
  };

  const handleCreateNewHabit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newHabitName.trim()) return;

    const baseXP = parseInt(newHabitBaseXP) || 60;
    const pShare = parseInt(newHabitPrimaryShare) || 80;
    const sShare = Math.max(0, 100 - pShare);

    const newHabit: HabitDefinition = {
      id: `custom_${Date.now()}`,
      name: newHabitName.trim(),
      category: newHabitCategory.trim(),
      description: newHabitDesc.trim() || 'Actividad configurada por el usuario.',
      iconName: 'Sparkles',
      primaryAttribute: newHabitPrimaryAttr,
      secondaryAttribute: newHabitSecondaryAttr === 'none' ? undefined : newHabitSecondaryAttr,
      primaryAttrShare: pShare,
      secondaryAttrShare: sShare,
      baseXP,
      metricBonusRate: parseFloat(newHabitMetricBonus) || 0,
      weeklyGoalBonusXP: 200,
      streakBonusXP: 15,
      weeklyGoalSessions: parseInt(newHabitGoal) || 5,
      metricLabel: newHabitMetricLabel.trim() || 'Tiempo',
      metricUnit: newHabitMetricUnit.trim() || 'min',
      isPrivate: false,
      color: '#10b981',
      isCustom: true,
    };

    const updated = [...localHabits, newHabit];
    setLocalHabits(updated);
    onUpdateHabits(updated);
    setShowNewHabitModal(false);
    soundEffects.playLevelUp();

    // Reset fields
    setNewHabitName('');
    setNewHabitDesc('');
  };

  return (
    <div className="space-y-4 pb-20">
      {/* Top Banner */}
      <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-xl flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2">
            <Sliders className="w-5 h-5 text-cyan-400" />
            <h1 className="text-lg font-black text-white font-rpg tracking-wide">
              Configurador de EXP y Atributos
            </h1>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Personaliza exactamente cuánta EXP da cada actividad y a qué atributos suma
          </p>
        </div>

        <button
          onClick={() => setShowNewHabitModal(true)}
          className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold shadow-md shadow-cyan-500/20 active:scale-95 transition"
        >
          <Plus className="w-4 h-4" />
          <span>Añadir Actividad</span>
        </button>
      </div>

      {/* Rules Explanatory Help Card */}
      <div className="p-3.5 rounded-2xl bg-cyan-950/30 border border-cyan-800/40 text-xs text-cyan-200">
        <div className="flex items-center gap-1.5 font-bold mb-1 text-cyan-300">
          <HelpCircle className="w-4 h-4" />
          <span>¿Cómo funciona el motor de reglas RPG?</span>
        </div>
        <p className="text-slate-300 leading-relaxed text-[11px]">
          Cada vez que marcas una actividad como completada, se calcula la EXP base más los bonus por métrica y racha. Luego, esa experiencia se distribuye automáticamente entre los atributos que tú definas (por ejemplo: 80% a Fuerza y 20% a Disciplina). ¡Tú tienes el control total del balance!
        </p>
      </div>

      {/* Habits Configuration Cards */}
      <div className="space-y-4">
        {localHabits.map((habit) => {
          const primaryShare = habit.primaryAttrShare ?? 80;
          const secondaryShare = habit.secondaryAttrShare ?? (100 - primaryShare);

          return (
            <div
              key={habit.id}
              className="p-4 rounded-2xl bg-[#0d1424] border border-slate-800 shadow-xl space-y-4 transition-all hover:border-slate-700"
            >
              {/* Header */}
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div className="flex items-center gap-2.5">
                  <div
                    className="w-3.5 h-3.5 rounded-full"
                    style={{ backgroundColor: habit.color || '#3b82f6' }}
                  />
                  <div>
                    <h3 className="text-sm font-black text-white font-rpg">{habit.name}</h3>
                    <span className="text-[10px] text-slate-400">{habit.category}</span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono-num font-bold text-cyan-400 bg-cyan-950/80 px-2.5 py-1 rounded-lg border border-cyan-800/60">
                    +{habit.baseXP} EXP Base
                  </span>
                  {habit.isCustom && (
                    <button
                      onClick={() => handleDeleteHabit(habit.id)}
                      title="Eliminar actividad personalizada"
                      className="p-1.5 rounded-lg text-rose-400 hover:text-white hover:bg-rose-950/40 transition"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>

              {/* Grid: XP Base & Attributes Mapping */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                {/* 1. EXP Base Input */}
                <div className="p-3 bg-slate-950/70 rounded-xl border border-slate-800 space-y-1.5">
                  <div className="flex items-center justify-between">
                    <label className="font-semibold text-slate-300 flex items-center gap-1.5">
                      <Zap className="w-3.5 h-3.5 text-amber-400" />
                      <span>EXP Base por sesión</span>
                    </label>
                    <span className="text-[10px] text-slate-500 font-mono-num">puntos</span>
                  </div>
                  <input
                    type="number"
                    min="10"
                    max="1000"
                    step="5"
                    value={habit.baseXP}
                    onChange={(e) =>
                      handleHabitFieldChange(habit.id, 'baseXP', parseInt(e.target.value) || 10)
                    }
                    className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-white font-mono-num font-bold text-sm focus:outline-none focus:border-cyan-500"
                  />
                  <span className="text-[10px] text-slate-400 block">
                    Experiencia inmediata al marcar la actividad como completada.
                  </span>
                </div>

                {/* 2. Bonus por Métrica */}
                <div className="p-3 bg-slate-950/70 rounded-xl border border-slate-800 space-y-1.5">
                  <div className="flex items-center justify-between">
                    <label className="font-semibold text-slate-300 flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                      <span>Bonus por {habit.metricUnit || 'unidad'}</span>
                    </label>
                    <span className="text-[10px] text-slate-500 font-mono-num">+{habit.metricBonusRate} EXP/u</span>
                  </div>
                  <input
                    type="number"
                    min="0"
                    max="100"
                    step="1"
                    value={habit.metricBonusRate ?? 0}
                    onChange={(e) =>
                      handleHabitFieldChange(habit.id, 'metricBonusRate', parseFloat(e.target.value) || 0)
                    }
                    className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-white font-mono-num font-bold text-sm focus:outline-none focus:border-cyan-500"
                  />
                  <span className="text-[10px] text-slate-400 block">
                    Ej: +{habit.metricBonusRate} EXP por cada {habit.metricUnit} adicional registrado.
                  </span>
                </div>
              </div>

              {/* Attributes Distribution (A QUÉ LE SUMA) */}
              <div className="p-3.5 bg-slate-950/80 rounded-xl border border-slate-800 space-y-3">
                <span className="text-[11px] font-bold text-cyan-400 uppercase tracking-wider block">
                  Distribución de Atributos: ¿A qué le suma la experiencia?
                </span>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {/* Atributo Principal */}
                  <div className="space-y-1">
                    <label className="text-xs text-slate-300 font-semibold block">
                      Atributo Principal (Mayor impacto)
                    </label>
                    <select
                      value={habit.primaryAttribute}
                      onChange={(e) =>
                        handleHabitFieldChange(habit.id, 'primaryAttribute', e.target.value as AttributeKey)
                      }
                      className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-white text-xs font-semibold focus:outline-none focus:border-cyan-500"
                    >
                      {attributeOptions.map((opt) => (
                        <option key={opt.key} value={opt.key}>
                          {opt.name}
                        </option>
                      ))}
                    </select>

                    <div className="flex items-center gap-2 pt-1">
                      <span className="text-[10px] text-slate-400">Porcentaje:</span>
                      <input
                        type="range"
                        min="50"
                        max="100"
                        step="5"
                        value={primaryShare}
                        onChange={(e) =>
                          handleHabitFieldChange(habit.id, 'primaryAttrShare', parseInt(e.target.value))
                        }
                        className="flex-1 accent-cyan-400"
                      />
                      <span className="text-xs font-mono-num font-bold text-cyan-400 w-10 text-right">
                        {primaryShare}%
                      </span>
                    </div>
                  </div>

                  {/* Atributo Secundario */}
                  <div className="space-y-1">
                    <label className="text-xs text-slate-300 font-semibold block">
                      Atributo Secundario (Impacto complementario)
                    </label>
                    <select
                      value={habit.secondaryAttribute || 'none'}
                      onChange={(e) =>
                        handleHabitFieldChange(
                          habit.id,
                          'secondaryAttribute',
                          e.target.value as any
                        )
                      }
                      className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-white text-xs font-semibold focus:outline-none focus:border-cyan-500"
                    >
                      <option value="none">Ninguno (100% al principal)</option>
                      {attributeOptions.map((opt) => (
                        <option key={opt.key} value={opt.key}>
                          {opt.name}
                        </option>
                      ))}
                    </select>

                    {habit.secondaryAttribute && habit.secondaryAttribute !== 'none' && (
                      <div className="flex items-center gap-2 pt-1">
                        <span className="text-[10px] text-slate-400">Porcentaje:</span>
                        <div className="flex-1 h-2 bg-slate-800 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-blue-500"
                            style={{ width: `${secondaryShare}%` }}
                          />
                        </div>
                        <span className="text-xs font-mono-num font-bold text-blue-400 w-10 text-right">
                          {secondaryShare}%
                        </span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Real-time preview breakdown */}
                <div className="p-2.5 rounded-lg bg-slate-900/60 border border-slate-800 text-[11px] text-slate-300 flex items-center justify-between">
                  <span>Simulación de 1 sesión:</span>
                  <span className="font-mono-num">
                    +{Math.round(habit.baseXP * (primaryShare / 100))} EXP a{' '}
                    <strong className="text-cyan-400">
                      {attributeOptions.find((a) => a.key === habit.primaryAttribute)?.name}
                    </strong>
                    {habit.secondaryAttribute && habit.secondaryAttribute !== 'none'
                      ? ` y +${Math.round(habit.baseXP * (secondaryShare / 100))} EXP a ${
                          attributeOptions.find((a) => a.key === habit.secondaryAttribute)?.name
                        }`
                      : ''}
                  </span>
                </div>
              </div>

              {/* Bonus por Racha y Meta Semanal */}
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div className="p-2.5 bg-slate-950/70 rounded-xl border border-slate-800 flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <Flame className="w-3.5 h-3.5 text-amber-500" />
                    <span className="text-slate-300">Bonus por Racha Activa:</span>
                  </div>
                  <input
                    type="number"
                    min="0"
                    max="200"
                    value={habit.streakBonusXP ?? 15}
                    onChange={(e) =>
                      handleHabitFieldChange(habit.id, 'streakBonusXP', parseInt(e.target.value) || 0)
                    }
                    className="w-16 px-2 py-1 bg-slate-900 border border-slate-700 text-center rounded-lg font-mono-num font-bold text-amber-400"
                  />
                </div>

                <div className="p-2.5 bg-slate-950/70 rounded-xl border border-slate-800 flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <Target className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-slate-300">Bonus Meta Semanal:</span>
                  </div>
                  <input
                    type="number"
                    min="0"
                    max="1000"
                    step="50"
                    value={habit.weeklyGoalBonusXP ?? 200}
                    onChange={(e) =>
                      handleHabitFieldChange(habit.id, 'weeklyGoalBonusXP', parseInt(e.target.value) || 0)
                    }
                    className="w-16 px-2 py-1 bg-slate-900 border border-slate-700 text-center rounded-lg font-mono-num font-bold text-emerald-400"
                  />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Floating Bottom Action Bar */}
      <div className="sticky bottom-20 z-30 flex items-center justify-between gap-3 p-3 rounded-2xl bg-[#080d1a]/95 backdrop-blur-xl border border-slate-800 shadow-2xl">
        <button
          onClick={() => {
            if (window.confirm('¿Deseas restablecer todas las reglas de EXP a los valores iniciales?')) {
              onResetHabitsToDefault();
            }
          }}
          className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 text-xs font-semibold transition"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Restablecer Defecto</span>
        </button>

        <button
          onClick={handleSaveAllRules}
          className="flex items-center gap-1.5 px-6 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs shadow-lg shadow-cyan-500/25 active:scale-95 transition"
        >
          {savedSuccess ? <Check className="w-4 h-4" /> : <Award className="w-4 h-4" />}
          <span>{savedSuccess ? '¡Reglas Guardadas!' : 'Guardar y Aplicar Reglas'}</span>
        </button>
      </div>

      {/* Modal: Create New Custom Habit */}
      {showNewHabitModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
          <div className="relative w-full max-w-md rounded-2xl bg-[#0d1424] border border-slate-800 p-5 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-cyan-400" />
                <h3 className="text-base font-bold text-white font-rpg">Crear Nueva Actividad</h3>
              </div>
              <button
                onClick={() => setShowNewHabitModal(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateNewHabit} className="mt-4 space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Nombre de la actividad *</label>
                <input
                  type="text"
                  required
                  placeholder="Ej. Lectura y Estudio, Meditación, Programación..."
                  value={newHabitName}
                  onChange={(e) => setNewHabitName(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-white focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Categoría</label>
                <input
                  type="text"
                  placeholder="Ej. Mente & Intelecto, Bienestar..."
                  value={newHabitCategory}
                  onChange={(e) => setNewHabitCategory(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-white focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">EXP Base al completar</label>
                  <input
                    type="number"
                    min="10"
                    max="500"
                    value={newHabitBaseXP}
                    onChange={(e) => setNewHabitBaseXP(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-white font-mono-num font-bold focus:outline-none focus:border-cyan-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Meta semanal (sesiones)</label>
                  <input
                    type="number"
                    min="1"
                    max="14"
                    value={newHabitGoal}
                    onChange={(e) => setNewHabitGoal(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-white font-mono-num font-bold focus:outline-none focus:border-cyan-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Atributo Principal</label>
                  <select
                    value={newHabitPrimaryAttr}
                    onChange={(e) => setNewHabitPrimaryAttr(e.target.value as AttributeKey)}
                    className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-white font-semibold focus:outline-none focus:border-cyan-500"
                  >
                    {attributeOptions.map((opt) => (
                      <option key={opt.key} value={opt.key}>
                        {opt.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Atributo Secundario</label>
                  <select
                    value={newHabitSecondaryAttr}
                    onChange={(e) => setNewHabitSecondaryAttr(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-white font-semibold focus:outline-none focus:border-cyan-500"
                  >
                    <option value="none">Ninguno</option>
                    {attributeOptions.map((opt) => (
                      <option key={opt.key} value={opt.key}>
                        {opt.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Unidad de medida</label>
                  <input
                    type="text"
                    placeholder="páginas, minutos, series..."
                    value={newHabitMetricUnit}
                    onChange={(e) => setNewHabitMetricUnit(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-white focus:outline-none focus:border-cyan-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">EXP extra por unidad</label>
                  <input
                    type="number"
                    min="0"
                    max="50"
                    value={newHabitMetricBonus}
                    onChange={(e) => setNewHabitMetricBonus(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-white font-mono-num focus:outline-none focus:border-cyan-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Descripción breve</label>
                <textarea
                  rows={2}
                  placeholder="Enfoque de la actividad..."
                  value={newHabitDesc}
                  onChange={(e) => setNewHabitDesc(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-white focus:outline-none focus:border-cyan-500 resize-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowNewHabitModal(false)}
                  className="px-3 py-2 rounded-lg text-slate-400 hover:text-white"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold shadow-md shadow-cyan-500/20"
                >
                  Crear Actividad
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
