import React, { useState } from 'react';
import {
  HabitDefinition,
  HabitLog,
  HabitStatus,
  PlayerProfile,
} from '../../types/game';
import { soundEffects } from '../../utils/soundEffects';
import {
  CheckCircle2,
  Clock,
  XCircle,
  Dumbbell,
  Footprints,
  Palette,
  Shield,
  Edit2,
  Calendar as CalendarIcon,
  Settings,
  FileText,
  Plus,
} from 'lucide-react';

interface MissionsViewProps {
  habits: HabitDefinition[];
  logs: HabitLog[];
  profile: PlayerProfile;
  selectedDate: string;
  onSelectDate: (date: string) => void;
  onSaveLog: (log: Omit<HabitLog, 'id' | 'timestamp'>) => void;
  onOpenHabitDetail: (habitId: string) => void;
  onUpdateHabitGoals: (habitId: string, newGoal: number) => void;
  onNavigateToRules?: () => void;
}

export const MissionsView: React.FC<MissionsViewProps> = ({
  habits,
  logs,
  profile,
  selectedDate,
  onSelectDate,
  onSaveLog,
  onOpenHabitDetail,
  onUpdateHabitGoals,
  onNavigateToRules,
}) => {
  const [editingGoals, setEditingGoals] = useState(false);
  const [goalInputs, setGoalInputs] = useState<Record<string, number>>(
    Object.fromEntries(habits.map((h) => [h.id, h.weeklyGoalSessions]))
  );

  const getHabitIcon = (id: string) => {
    switch (id) {
      case 'gym':
        return <Dumbbell className="w-5 h-5 text-blue-400" />;
      case 'running':
        return <Footprints className="w-5 h-5 text-cyan-400" />;
      case 'drawing':
        return <Palette className="w-5 h-5 text-amber-400" />;
      case 'abstinence':
        return <Shield className="w-5 h-5 text-purple-400" />;
      default:
        return <Dumbbell className="w-5 h-5 text-cyan-400" />;
    }
  };

  const logsForSelectedDate = logs.filter((l) => l.date === selectedDate);
  const visibleHabits = habits.filter((h) => !h.isPrivate || !profile.privateModeHidden);

  const handleStatusClick = (habit: HabitDefinition, status: HabitStatus) => {
    soundEffects.playClick();
    const existing = logsForSelectedDate.find((l) => l.habitId === habit.id);
    onSaveLog({
      habitId: habit.id,
      date: selectedDate,
      status,
      sessionsCount: existing?.sessionsCount || 1,
      metricValue: existing?.metricValue,
      notes: existing?.notes,
      xpAwarded: status === 'completed' ? habit.baseXP : 0,
    });
  };

  const handleSaveGoals = () => {
    Object.entries(goalInputs).forEach(([id, goal]) => {
      onUpdateHabitGoals(id, goal);
    });
    setEditingGoals(false);
  };

  const todayStr = new Date().toISOString().split('T')[0];

  return (
    <div className="space-y-4 pb-20">
      {/* Header and Date Selector */}
      <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-xl">
        <div className="flex items-center justify-between gap-2">
          <div>
            <h1 className="text-lg font-black text-white font-rpg tracking-wide">
              Misiones y Registro Diario
            </h1>
            <p className="text-xs text-slate-400 mt-0.5">
              Registra tus entrenamientos, arte y hábitos para evolucionar
            </p>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            {onNavigateToRules && (
              <button
                onClick={onNavigateToRules}
                title="Configurar cuanta EXP da cada cosa y a qué suma"
                className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-cyan-950/80 hover:bg-cyan-900 text-cyan-300 text-xs font-semibold border border-cyan-800 transition"
              >
                <span>⚙️ Config EXP</span>
              </button>
            )}

            <button
              onClick={() => setEditingGoals(!editingGoals)}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition"
            >
              <Settings className="w-3.5 h-3.5" />
              <span>{editingGoals ? 'Cerrar' : 'Metas'}</span>
            </button>
          </div>
        </div>

        {/* Date Selector Row */}
        <div className="mt-4 flex items-center justify-between gap-2 p-2 rounded-xl bg-slate-950 border border-slate-800">
          <div className="flex items-center gap-2">
            <CalendarIcon className="w-4 h-4 text-cyan-400" />
            <span className="text-xs font-semibold text-slate-300">Fecha seleccionada:</span>
          </div>

          <div className="flex items-center gap-2">
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => onSelectDate(e.target.value)}
              className="px-2 py-1 bg-slate-900 border border-slate-700 rounded-lg text-xs font-mono-num text-white focus:outline-none focus:border-cyan-500"
            />
            {selectedDate !== todayStr && (
              <button
                onClick={() => onSelectDate(todayStr)}
                className="px-2 py-1 text-[11px] font-bold text-cyan-400 bg-cyan-950/80 border border-cyan-800 rounded-lg hover:bg-cyan-900 transition"
              >
                Hoy
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Goal Editor Drawer if open */}
      {editingGoals && (
        <div className="p-4 rounded-2xl bg-[#0e1628] border border-cyan-500/40 shadow-xl animate-in fade-in">
          <h3 className="text-sm font-bold text-white mb-2 font-rpg">
            Configurar Objetivos Semanales
          </h3>
          <p className="text-xs text-slate-400 mb-3">
            Establece cuántas sesiones por semana deseas completar en cada actividad.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {habits.map((habit) => (
              <div key={habit.id} className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center justify-between">
                <span className="text-xs font-semibold text-white">{habit.name}</span>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    min="1"
                    max="14"
                    value={goalInputs[habit.id] ?? habit.weeklyGoalSessions}
                    onChange={(e) =>
                      setGoalInputs({
                        ...goalInputs,
                        [habit.id]: parseInt(e.target.value) || 1,
                      })
                    }
                    className="w-14 px-2 py-1 bg-slate-950 border border-slate-700 text-center rounded-lg text-xs font-mono-num text-cyan-400 font-bold"
                  />
                  <span className="text-[11px] text-slate-400">/sem</span>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-3 flex justify-end">
            <button
              onClick={handleSaveGoals}
              className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs shadow-md shadow-cyan-500/20"
            >
              Guardar Metas Semanales
            </button>
          </div>
        </div>
      )}

      {/* Habits List for Selected Date */}
      <div className="space-y-3">
        {visibleHabits.map((habit) => {
          const log = logsForSelectedDate.find((l) => l.habitId === habit.id);
          const currentStatus: HabitStatus = log ? log.status : 'pending';

          return (
            <div
              key={habit.id}
              className={`p-4 rounded-2xl border transition-all ${
                currentStatus === 'completed'
                  ? 'bg-gradient-to-r from-slate-900 via-emerald-950/20 to-slate-900 border-emerald-500/40'
                  : currentStatus === 'skipped'
                  ? 'bg-slate-900/40 border-slate-800/80 opacity-75'
                  : 'bg-slate-900/80 border-slate-800'
              }`}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-start gap-3">
                  <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 shrink-0 mt-0.5">
                    {getHabitIcon(habit.id)}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-sm font-black text-white font-rpg">{habit.name}</h3>
                      <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-medium">
                        Meta: {habit.weeklyGoalSessions}/sem
                      </span>
                    </div>
                    <p className="text-xs text-slate-400 mt-0.5">{habit.description}</p>
                    
                    {/* Log Details if existing */}
                    {log && (
                      <div className="mt-2 flex flex-wrap items-center gap-2 text-xs text-slate-300">
                        {log.metricValue !== undefined && (
                          <span className="px-2 py-0.5 rounded bg-cyan-950/70 border border-cyan-800/60 text-cyan-300 font-mono-num text-[11px]">
                            {log.metricValue} {habit.metricUnit}
                          </span>
                        )}
                        {log.sessionsCount > 1 && (
                          <span className="px-2 py-0.5 rounded bg-blue-950/70 border border-blue-800/60 text-blue-300 font-mono-num text-[11px]">
                            {log.sessionsCount} sesiones
                          </span>
                        )}
                        {log.notes && (
                          <span className="flex items-center gap-1 text-[11px] text-slate-400 italic">
                            <FileText className="w-3 h-3 text-slate-500" />
                            "{log.notes}"
                          </span>
                        )}
                      </div>
                    )}
                  </div>
                </div>

                {/* Edit details button */}
                <button
                  onClick={() => onOpenHabitDetail(habit.id)}
                  title="Editar métricas o notas"
                  className="p-2 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-300 transition"
                >
                  <Edit2 className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Status Action Buttons */}
              <div className="mt-4 pt-3 border-t border-slate-800/60 flex items-center justify-between gap-2">
                <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                  Acción:
                </span>

                <div className="flex items-center gap-1.5">
                  {/* Completada */}
                  <button
                    onClick={() => handleStatusClick(habit, 'completed')}
                    className={`flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-semibold border transition active:scale-95 ${
                      currentStatus === 'completed'
                        ? 'bg-emerald-500 text-slate-950 border-emerald-400 shadow-sm shadow-emerald-500/30'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-emerald-400 hover:border-emerald-800'
                    }`}
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Completada (+{habit.baseXP} XP)</span>
                  </button>

                  {/* Pendiente */}
                  <button
                    onClick={() => handleStatusClick(habit, 'pending')}
                    className={`flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-xs font-semibold border transition active:scale-95 ${
                      currentStatus === 'pending'
                        ? 'bg-amber-500/20 text-amber-300 border-amber-500/50'
                        : 'bg-slate-950 border-slate-800 text-slate-500 hover:text-amber-400'
                    }`}
                  >
                    <Clock className="w-3.5 h-3.5" />
                    <span>Pendiente</span>
                  </button>

                  {/* No Realizada */}
                  <button
                    onClick={() => handleStatusClick(habit, 'skipped')}
                    className={`flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-xs font-semibold border transition active:scale-95 ${
                      currentStatus === 'skipped'
                        ? 'bg-slate-800 text-slate-300 border-slate-700'
                        : 'bg-slate-950 border-slate-800 text-slate-500 hover:text-slate-400'
                    }`}
                  >
                    <XCircle className="w-3.5 h-3.5" />
                    <span>Descanso</span>
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Recent History Snippet */}
      <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 shadow-lg">
        <h3 className="text-sm font-bold text-white mb-2 font-rpg">
          Historial Reciente de Misiones
        </h3>
        <div className="divide-y divide-slate-800">
          {logs.slice(-5).reverse().map((l) => {
            const h = habits.find((hab) => hab.id === l.habitId);
            return (
              <div key={l.id} className="py-2.5 flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <span className="font-mono-num text-slate-400">{l.date}</span>
                  <span className="text-slate-600">·</span>
                  <span className="font-semibold text-white">{h?.name || l.habitId}</span>
                  {l.metricValue && (
                    <span className="text-slate-400 font-mono-num">
                      ({l.metricValue} {h?.metricUnit})
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                    l.status === 'completed'
                      ? 'bg-emerald-950 text-emerald-400 border border-emerald-800/60'
                      : 'bg-slate-800 text-slate-400'
                  }`}>
                    {l.status === 'completed' ? `+${l.xpAwarded} XP` : l.status}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
