import React, { useState } from 'react';
import {
  PlayerProfile,
  CharacterAppearance,
  Achievement,
  HairStyle,
  FacialHair,
  OutfitType,
  AccessoryType,
  AuraEffect,
  ArtStyle,
} from '../../types/game';
import { CharacterCanvas } from '../character/CharacterCanvas';
import { soundEffects } from '../../utils/soundEffects';
import {
  User,
  Palette,
  Trophy,
  Smartphone,
  Download,
  Upload,
  RotateCcw,
  Volume2,
  VolumeX,
  EyeOff,
  Eye,
  Check,
  Shield,
  Sparkles,
} from 'lucide-react';

interface ProfileRPGViewProps {
  profile: PlayerProfile;
  achievements: Achievement[];
  pendingMissionsCount: number;
  onUpdateProfile: (updated: Partial<PlayerProfile>) => void;
  onUpdateAppearance: (updated: Partial<CharacterAppearance>) => void;
  onExportData: () => void;
  onImportData: (json: string) => boolean;
  onResetData: () => void;
  onOpenMeasurementModal: () => void;
}

export const ProfileRPGView: React.FC<ProfileRPGViewProps> = ({
  profile,
  achievements,
  pendingMissionsCount,
  onUpdateProfile,
  onUpdateAppearance,
  onExportData,
  onImportData,
  onResetData,
  onOpenMeasurementModal,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'profile' | 'customization' | 'achievements' | 'widget' | 'settings'>('profile');
  const [importJsonText, setImportJsonText] = useState('');
  const [importMessage, setImportMessage] = useState<string | null>(null);

  // Form local state for profile editing
  const [name, setName] = useState(profile.name);
  const [age, setAge] = useState(String(profile.age));
  const [heightCm, setHeightCm] = useState(String(profile.heightCm));
  const [personalGoals, setPersonalGoals] = useState(profile.personalGoals);
  const [characterBio, setCharacterBio] = useState(profile.characterBio);
  const [targetDescription, setTargetDescription] = useState(profile.targetDescription);
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    soundEffects.playClick();
    onUpdateProfile({
      name: name.trim() || 'Gabriel',
      age: parseInt(age) || 25,
      heightCm: parseInt(heightCm) || 178,
      personalGoals,
      characterBio,
      targetDescription,
    });
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2000);
  };

  const handleImportSubmit = () => {
    if (!importJsonText.trim()) return;
    const ok = onImportData(importJsonText);
    if (ok) {
      soundEffects.playLevelUp();
      setImportMessage('¡Copia de seguridad restaurada con éxito!');
      setImportJsonText('');
    } else {
      setImportMessage('Error: El archivo JSON no tiene un formato válido.');
    }
    setTimeout(() => setImportMessage(null), 4000);
  };

  const skinTones = [
    { label: 'Pálido', hex: '#fce0cc' },
    { label: 'Claro', hex: '#f5c6a5' },
    { label: 'Trigueño', hex: '#e0a97d' },
    { label: 'Bronceado', hex: '#d4986a' },
    { label: 'Oscuro', hex: '#a66838' },
    { label: 'Ébano', hex: '#633919' },
  ];

  const hairColors = [
    { label: 'Negro Azabache', hex: '#1e1b18' },
    { label: 'Castaño Oscuro', hex: '#452b1f' },
    { label: 'Castaño Claro', hex: '#8b5a2b' },
    { label: 'Rubio Anime', hex: '#e2ba64' },
    { label: 'Plata / Blanco', hex: '#cbd5e1' },
    { label: 'Azul Eléctrico', hex: '#2563eb' },
    { label: 'Carmesí Furia', hex: '#dc2626' },
  ];

  const outfitColors = [
    { label: 'Azul Real', hex: '#2563eb' },
    { label: 'Negro Táctico', hex: '#0f172a' },
    { label: 'Rojo Carmesí', hex: '#dc2626' },
    { label: 'Verde Élite', hex: '#059669' },
    { label: 'Púrpura Místico', hex: '#7c3aed' },
    { label: 'Naranja Guerrero', hex: '#ea580c' },
  ];

  return (
    <div className="space-y-4 pb-20">
      {/* Sub-tab Switcher */}
      <div className="p-1.5 rounded-2xl bg-slate-900/90 border border-slate-800 flex items-center gap-1 overflow-x-auto shadow-lg">
        {[
          { id: 'profile', label: 'Datos Personales', icon: User },
          { id: 'customization', label: 'Personalizar Avatar', icon: Palette },
          { id: 'achievements', label: 'Salón de Logros', icon: Trophy },
          { id: 'widget', label: 'Widget Android', icon: Smartphone },
          { id: 'settings', label: 'Ajustes & Copia', icon: Shield },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeSubTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => {
                soundEffects.playClick();
                setActiveSubTab(tab.id as any);
              }}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                isActive
                  ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* ========================================================= */}
      {/* SUBTAB 1: PERFIL PERSONAL */}
      {/* ========================================================= */}
      {activeSubTab === 'profile' && (
        <div className="space-y-4 animate-in fade-in">
          {/* Identity & Physical Card */}
          <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-xl">
            <h2 className="text-sm font-black text-white font-rpg uppercase tracking-wider mb-1">
              Ficha del Protagonista
            </h2>
            <p className="text-xs text-slate-400 mb-4">
              Configura tus datos reales para alimentar los cálculos y el progreso
            </p>

            <form onSubmit={handleSaveProfile} className="space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {/* Nombre */}
                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-1">Nombre o Apodo</label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white text-xs focus:outline-none focus:border-cyan-500"
                  />
                </div>

                {/* Edad */}
                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-1">Edad</label>
                  <input
                    type="number"
                    value={age}
                    onChange={(e) => setAge(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white text-xs font-mono-num focus:outline-none focus:border-cyan-500"
                  />
                </div>

                {/* Altura */}
                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-1">Altura (cm)</label>
                  <input
                    type="number"
                    value={heightCm}
                    onChange={(e) => setHeightCm(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white text-xs font-mono-num focus:outline-none focus:border-cyan-500"
                  />
                </div>
              </div>

              {/* Physical Measurements Summary with quick edit button */}
              <div className="p-3 bg-slate-950/70 rounded-xl border border-slate-800 flex items-center justify-between">
                <div className="grid grid-cols-3 gap-4 text-xs">
                  <div>
                    <span className="text-slate-400 text-[10px] block uppercase">Peso Actual</span>
                    <strong className="text-white font-mono-num">{profile.currentWeightKg} kg</strong>
                  </div>
                  <div>
                    <span className="text-slate-400 text-[10px] block uppercase">% Grasa</span>
                    <strong className="text-cyan-400 font-mono-num">{profile.currentBodyFatPercent}%</strong>
                  </div>
                  <div>
                    <span className="text-slate-400 text-[10px] block uppercase">Masa Muscular</span>
                    <strong className="text-blue-400 font-mono-num">{profile.currentMuscleMassKg || '--'} kg</strong>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={onOpenMeasurementModal}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-400 text-xs font-semibold transition"
                >
                  Actualizar Mediciones
                </button>
              </div>

              {/* Narrative Fields */}
              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1">
                  Objetivos Personales
                </label>
                <textarea
                  rows={2}
                  value={personalGoals}
                  onChange={(e) => setPersonalGoals(e.target.value)}
                  placeholder="¿Cuáles son tus principales metas físicas y mentales?"
                  className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white text-xs focus:outline-none focus:border-cyan-500 resize-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1">
                  Descripción del Personaje y la Persona en la que quieres convertirte
                </label>
                <textarea
                  rows={2}
                  value={targetDescription}
                  onChange={(e) => setTargetDescription(e.target.value)}
                  placeholder="Describe la persona disciplinada, fuerte y segura en la que te estás transformando..."
                  className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white text-xs focus:outline-none focus:border-cyan-500 resize-none"
                />
              </div>

              <div className="flex items-center justify-between pt-2">
                <span className="text-xs text-slate-400">
                  Inicio de la aventura: <strong className="text-slate-300 font-mono-num">{profile.startDate}</strong>
                </span>

                <button
                  type="submit"
                  className="flex items-center gap-1.5 px-5 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs shadow-md shadow-cyan-500/20 active:scale-95 transition"
                >
                  {savedSuccess ? <Check className="w-4 h-4" /> : null}
                  <span>{savedSuccess ? '¡Guardado!' : 'Guardar Perfil'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* SUBTAB 2: PERSONALIZAR PERSONAJE */}
      {/* ========================================================= */}
      {activeSubTab === 'customization' && (
        <div className="space-y-4 animate-in fade-in">
          <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-xl">
            <h2 className="text-sm font-black text-white font-rpg uppercase tracking-wider mb-1">
              Taller de Personalización del Héroe
            </h2>
            <p className="text-xs text-slate-400 mb-3">
              Modifica la apariencia, peinado, ropa, accesorios y efectos visuales de aura
            </p>

            {/* Live Character Preview */}
            <div className="mb-4">
              <CharacterCanvas
                appearance={profile.appearance}
                weightKg={profile.currentWeightKg}
                bodyFatPercent={profile.currentBodyFatPercent}
                muscleMassKg={profile.currentMuscleMassKg}
                heightCm={profile.heightCm}
                level={profile.level}
                interactive={true}
                onViewChange={(view) => onUpdateAppearance({ viewAngle: view })}
                onPoseChange={(pose) => onUpdateAppearance({ currentPose: pose })}
              />
            </div>

            <div className="space-y-4 text-xs">
              {/* Tono de piel */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-2">Tono de piel</label>
                <div className="flex items-center gap-2 overflow-x-auto pb-1">
                  {skinTones.map((st) => (
                    <button
                      key={st.hex}
                      onClick={() => onUpdateAppearance({ skinTone: st.hex })}
                      title={st.label}
                      className={`w-8 h-8 rounded-full border-2 transition ${
                        profile.appearance.skinTone === st.hex
                          ? 'border-cyan-400 scale-110 shadow-md shadow-cyan-500/40'
                          : 'border-slate-700'
                      }`}
                      style={{ backgroundColor: st.hex }}
                    />
                  ))}
                </div>
              </div>

              {/* Forma del Rostro / Mentón Anime */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-2">Forma del Rostro Anime</label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'sharp_v', label: 'Mentón en V (Shonen)' },
                    { id: 'athletic_jaw', label: 'Mandíbula Atlética' },
                    { id: 'soft', label: 'Rostro Suave' },
                  ].map((fs) => (
                    <button
                      key={fs.id}
                      onClick={() => onUpdateAppearance({ faceShape: fs.id as any })}
                      className={`p-2 rounded-xl border text-center transition ${
                        profile.appearance.faceShape === fs.id
                          ? 'bg-cyan-500 text-slate-950 font-bold border-cyan-400'
                          : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                      }`}
                    >
                      {fs.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Ojos Anime: Color y Mirada */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-2">Color de Ojos Anime</label>
                <div className="flex items-center gap-2 overflow-x-auto pb-1">
                  {[
                    { label: 'Cian Relámpago', hex: '#38bdf8' },
                    { label: 'Rojo Carmesí', hex: '#ef4444' },
                    { label: 'Dorado Super Saiyan', hex: '#fbbf24' },
                    { label: 'Verde Esmeralda', hex: '#10b981' },
                    { label: 'Púrpura Místico', hex: '#a855f7' },
                    { label: 'Negro Ónice', hex: '#0f172a' },
                  ].map((ec) => (
                    <button
                      key={ec.hex}
                      onClick={() => onUpdateAppearance({ eyeColor: ec.hex })}
                      title={ec.label}
                      className={`w-8 h-8 rounded-full border-2 transition ${
                        profile.appearance.eyeColor === ec.hex
                          ? 'border-cyan-400 scale-110 shadow-md shadow-cyan-500/40'
                          : 'border-slate-700'
                      }`}
                      style={{ backgroundColor: ec.hex }}
                    />
                  ))}
                </div>
              </div>

              {/* Peinado Anime Expandido */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-2">Estilo de peinado Anime</label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'anime_messy', label: 'Anime Despeinado' },
                    { id: 'supersaiyan', label: 'Super Saiyan (Puntas Altas)' },
                    { id: 'short_spiky', label: 'Puntas Shonen' },
                    { id: 'undercut', label: 'Undercut Moderno' },
                    { id: 'long_warrior', label: 'Guerrero Largo' },
                    { id: 'ponytail', label: 'Coleta Samurai' },
                    { id: 'buzz', label: 'Corte Militar' },
                  ].map((h) => (
                    <button
                      key={h.id}
                      onClick={() => onUpdateAppearance({ hairStyle: h.id as HairStyle })}
                      className={`p-2 rounded-xl border text-center transition ${
                        profile.appearance.hairStyle === h.id
                          ? 'bg-cyan-500 text-slate-950 font-bold border-cyan-400'
                          : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                      }`}
                    >
                      {h.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Color de Pelo */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-2">Color de pelo</label>
                <div className="flex items-center gap-2 overflow-x-auto pb-1">
                  {hairColors.map((hc) => (
                    <button
                      key={hc.hex}
                      onClick={() => onUpdateAppearance({ hairColor: hc.hex })}
                      title={hc.label}
                      className={`w-8 h-8 rounded-full border-2 transition ${
                        profile.appearance.hairColor === hc.hex
                          ? 'border-cyan-400 scale-110 shadow-md shadow-cyan-500/40'
                          : 'border-slate-700'
                      }`}
                      style={{ backgroundColor: hc.hex }}
                    />
                  ))}
                </div>
              </div>

              {/* Vello Facial */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-2">Vello facial</label>
                <div className="grid grid-cols-4 gap-2">
                  {[
                    { id: 'none', label: 'Afeitado' },
                    { id: 'stubble', label: 'Barba corta' },
                    { id: 'beard_short', label: 'Barba completa' },
                    { id: 'goatee', label: 'Perilla' },
                  ].map((f) => (
                    <button
                      key={f.id}
                      onClick={() => onUpdateAppearance({ facialHair: f.id as FacialHair })}
                      className={`p-2 rounded-xl border text-center transition ${
                        profile.appearance.facialHair === f.id
                          ? 'bg-cyan-500 text-slate-950 font-bold border-cyan-400'
                          : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                      }`}
                    >
                      {f.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Atuendo */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-2">Atuendo</label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'gym_tank', label: 'Camiseta de Tirantes' },
                    { id: 'hoodie_athlete', label: 'Sudadera Atleta' },
                    { id: 'monk_gi', label: 'Kimono de Monje' },
                    { id: 'elite_armor', label: 'Armadura Ligera' },
                    { id: 'shadow_assassin', label: 'Ropa Táctica' },
                  ].map((o) => (
                    <button
                      key={o.id}
                      onClick={() => onUpdateAppearance({ outfit: o.id as OutfitType })}
                      className={`p-2 rounded-xl border text-center transition ${
                        profile.appearance.outfit === o.id
                          ? 'bg-cyan-500 text-slate-950 font-bold border-cyan-400'
                          : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                      }`}
                    >
                      {o.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Color del Atuendo */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-2">Color del atuendo</label>
                <div className="flex items-center gap-2 overflow-x-auto pb-1">
                  {outfitColors.map((oc) => (
                    <button
                      key={oc.hex}
                      onClick={() => onUpdateAppearance({ outfitColor: oc.hex })}
                      title={oc.label}
                      className={`w-8 h-8 rounded-full border-2 transition ${
                        profile.appearance.outfitColor === oc.hex
                          ? 'border-cyan-400 scale-110 shadow-md shadow-cyan-500/40'
                          : 'border-slate-700'
                      }`}
                      style={{ backgroundColor: oc.hex }}
                    />
                  ))}
                </div>
              </div>

              {/* Accesorios & Katana */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-2">Accesorios Anime</label>
                <div className="grid grid-cols-3 sm:grid-cols-5 gap-2 mb-2">
                  {[
                    { id: 'none', label: 'Ninguno' },
                    { id: 'headband', label: 'Cinta Ninja' },
                    { id: 'wrist_wraps', label: 'Muñequeras' },
                    { id: 'scouter', label: 'Scouter Visor' },
                    { id: 'fox_mask', label: 'Máscara Kitsune' },
                  ].map((acc) => (
                    <button
                      key={acc.id}
                      onClick={() => onUpdateAppearance({ accessory: acc.id as AccessoryType })}
                      className={`p-2 rounded-xl border text-center transition ${
                        profile.appearance.accessory === acc.id
                          ? 'bg-cyan-500 text-slate-950 font-bold border-cyan-400'
                          : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                      }`}
                    >
                      {acc.label}
                    </button>
                  ))}
                </div>

                {/* Katana On Back Toggle */}
                <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                  <div>
                    <span className="text-xs font-bold text-white block">Katana Cruzada a la Espalda</span>
                    <span className="text-[10px] text-slate-400">Vaina tradicional con empuñadura sobre el hombro</span>
                  </div>
                  <button
                    onClick={() => onUpdateAppearance({ katanaOnBack: !profile.appearance.katanaOnBack })}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                      profile.appearance.katanaOnBack ? 'bg-cyan-500 text-slate-950' : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {profile.appearance.katanaOnBack ? 'Equipada' : 'Desequipada'}
                  </button>
                </div>
              </div>

              {/* Efecto de Aura */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-2">Efecto de Aura de Poder</label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'none', label: 'Sin Aura' },
                    { id: 'ki_blue', label: 'Ki Azul' },
                    { id: 'golden_super', label: 'Super Saiyan Dorado' },
                    { id: 'crimson_rage', label: 'Furia Carmesí' },
                    { id: 'emerald_focus', label: 'Foco Esmeralda' },
                  ].map((aura) => (
                    <button
                      key={aura.id}
                      onClick={() => onUpdateAppearance({ auraEffect: aura.id as AuraEffect })}
                      className={`p-2 rounded-xl border text-center transition ${
                        profile.appearance.auraEffect === aura.id
                          ? 'bg-cyan-500 text-slate-950 font-bold border-cyan-400'
                          : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                      }`}
                    >
                      {aura.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* SUBTAB 3: SALÓN DE LOGROS */}
      {/* ========================================================= */}
      {activeSubTab === 'achievements' && (
        <div className="space-y-3 animate-in fade-in">
          <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-xl">
            <h2 className="text-sm font-black text-white font-rpg uppercase tracking-wider mb-1">
              Salón de Trofeos y Hitos
            </h2>
            <p className="text-xs text-slate-400 mb-3">
              Completa hazañas para desbloquear experiencia y recompensas cosméticas exclusivas
            </p>

            <div className="space-y-3">
              {achievements.map((ach) => {
                const pct = Math.min(Math.round((ach.currentValue / ach.targetValue) * 100), 100);
                return (
                  <div
                    key={ach.id}
                    className={`p-3.5 rounded-xl border transition ${
                      ach.isUnlocked
                        ? 'bg-gradient-to-r from-amber-950/30 via-slate-900 to-slate-900 border-amber-500/40 shadow-sm'
                        : 'bg-slate-950/70 border-slate-800'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-start gap-3">
                        <div
                          className={`p-2.5 rounded-xl border shrink-0 ${
                            ach.isUnlocked
                              ? 'bg-amber-500/20 border-amber-500/60 text-amber-400'
                              : 'bg-slate-900 border-slate-800 text-slate-600'
                          }`}
                        >
                          <Trophy className="w-5 h-5" />
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <h3 className="text-xs font-bold text-white">{ach.title}</h3>
                            {ach.isUnlocked && (
                              <span className="text-[9px] font-black px-1.5 py-0.5 rounded bg-amber-400 text-slate-950 uppercase">
                                Desbloqueado
                              </span>
                            )}
                          </div>
                          <p className="text-xs text-slate-400 mt-0.5">{ach.description}</p>
                          {ach.cosmeticReward && (
                            <div className="mt-1 flex items-center gap-1 text-[11px] text-cyan-400 font-medium">
                              <Sparkles className="w-3 h-3" />
                              <span>Recompensa: {ach.cosmeticReward}</span>
                            </div>
                          )}
                        </div>
                      </div>

                      <span className="text-xs font-mono-num font-bold text-amber-400 shrink-0">
                        +{ach.xpReward} XP
                      </span>
                    </div>

                    {/* Progress Bar */}
                    <div className="mt-2.5">
                      <div className="w-full h-1.5 rounded-full bg-slate-900 border border-slate-800 overflow-hidden">
                        <div
                          className={`h-full ${ach.isUnlocked ? 'bg-amber-400' : 'bg-cyan-500'}`}
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                      <div className="mt-1 flex justify-between text-[10px] text-slate-400 font-mono-num">
                        <span>
                          {ach.currentValue} / {ach.targetValue}
                        </span>
                        <span>{pct}%</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* SUBTAB 4: WIDGET ANDROID SIMULADOR */}
      {/* ========================================================= */}
      {activeSubTab === 'widget' && (
        <div className="space-y-4 animate-in fade-in">
          <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-xl">
            <h2 className="text-sm font-black text-white font-rpg uppercase tracking-wider mb-1">
              Simulador de Widget para Android
            </h2>
            <p className="text-xs text-slate-400 mb-4">
              Visualiza cómo se integran tus misiones y nivel en la pantalla de inicio de tu teléfono Android
            </p>

            {/* Note on Android Widget compatibility as requested by user */}
            <div className="p-3 bg-blue-950/40 border border-blue-800/60 rounded-xl text-xs text-blue-200 mb-4">
              <strong className="block mb-1 text-cyan-300">📱 Integración Android & PWA:</strong>
              Al instalar esta aplicación mediante el botón de PWA («Instalar en Android / Inicio»), puedes mantenerla en pantalla completa. La arquitectura de datos y estado ya está completamente desacoplada y lista para sincronizarse con un widget nativo de Android (Glance / AppWidgetProvider) en la etapa de empaquetado nativo (TWA/Capacitor).
            </div>

            {/* Widget 4x2 Simulation */}
            <div className="space-y-2">
              <span className="text-xs font-bold text-slate-300">Widget Android (Formato 4x2)</span>
              <div className="p-4 rounded-3xl bg-slate-950/90 border-2 border-cyan-500/50 shadow-2xl backdrop-blur-xl max-w-sm mx-auto">
                <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-cyan-500 text-slate-950 font-black flex items-center justify-center text-xs">
                      {profile.level}
                    </div>
                    <div>
                      <span className="text-xs font-black text-white block">{profile.name}</span>
                      <span className="text-[10px] text-cyan-400">Nivel {profile.level} · {profile.currentWeightKg} kg</span>
                    </div>
                  </div>
                  <span className="text-[10px] font-mono-num font-bold text-amber-400">
                    {pendingMissionsCount === 0 ? '¡Al día!' : `${pendingMissionsCount} pendientes`}
                  </span>
                </div>

                <div className="mt-2.5 space-y-1.5">
                  <div className="flex items-center justify-between text-xs text-slate-300">
                    <span>Gimnasio</span>
                    <span className="text-emerald-400 font-bold">Completado</span>
                  </div>
                  <div className="flex items-center justify-between text-xs text-slate-300">
                    <span>Correr</span>
                    <span className="text-cyan-400 font-bold">5.0 km</span>
                  </div>
                  <div className="flex items-center justify-between text-xs text-slate-300">
                    <span>Dibujo</span>
                    <span className="text-amber-400 font-bold">45 min</span>
                  </div>
                </div>

                <div className="mt-3 pt-2 border-t border-slate-800/80 flex justify-between items-center text-[10px] text-slate-400">
                  <span>Mi Propia Evolución</span>
                  <span className="text-cyan-400 font-semibold">Tocar para abrir</span>
                </div>
              </div>
            </div>

            {/* Widget 2x2 Simulation */}
            <div className="space-y-2 mt-6">
              <span className="text-xs font-bold text-slate-300">Widget Android Compacto (Formato 2x2)</span>
              <div className="w-44 h-44 p-3.5 rounded-3xl bg-slate-950/90 border-2 border-blue-500/50 shadow-2xl backdrop-blur-xl mx-auto flex flex-col justify-between">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-black text-cyan-400">NVL {profile.level}</span>
                  <span className="text-[10px] font-mono-num text-slate-400">{profile.currentWeightKg}kg</span>
                </div>

                <div className="text-center my-auto">
                  <span className="text-3xl font-black text-white font-mono-num">{profile.level}</span>
                  <span className="text-[10px] font-bold text-slate-300 block">{profile.name}</span>
                </div>

                <div className="w-full bg-slate-900 rounded-full h-1.5 overflow-hidden">
                  <div className="bg-cyan-400 h-full w-3/4" />
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* SUBTAB 5: AJUSTES, PRIVACIDAD Y COPIAS DE SEGURIDAD */}
      {/* ========================================================= */}
      {activeSubTab === 'settings' && (
        <div className="space-y-4 animate-in fade-in">
          {/* Preferences */}
          <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-xl space-y-3">
            <h2 className="text-sm font-black text-white font-rpg uppercase tracking-wider mb-2">
              Preferencias y Privacidad
            </h2>

            {/* Sound Toggle */}
            <div className="flex items-center justify-between p-3 rounded-xl bg-slate-950 border border-slate-800">
              <div className="flex items-center gap-2.5">
                {profile.soundEnabled ? <Volume2 className="w-4 h-4 text-cyan-400" /> : <VolumeX className="w-4 h-4 text-slate-500" />}
                <div>
                  <span className="text-xs font-bold text-white block">Efectos de Sonido RPG</span>
                  <span className="text-[11px] text-slate-400">Subidas de nivel, fanfarrias y toques</span>
                </div>
              </div>
              <button
                onClick={() => {
                  soundEffects.setEnabled(!profile.soundEnabled);
                  onUpdateProfile({ soundEnabled: !profile.soundEnabled });
                }}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                  profile.soundEnabled ? 'bg-cyan-500 text-slate-950' : 'bg-slate-800 text-slate-400'
                }`}
              >
                {profile.soundEnabled ? 'Activado' : 'Desactivado'}
              </button>
            </div>

            {/* Animations Toggle */}
            <div className="flex items-center justify-between p-3 rounded-xl bg-slate-950 border border-slate-800">
              <div className="flex items-center gap-2.5">
                <Sparkles className="w-4 h-4 text-amber-400" />
                <div>
                  <span className="text-xs font-bold text-white block">Animaciones de Aura y Celebración</span>
                  <span className="text-[11px] text-slate-400">Flotación de energía y confeti</span>
                </div>
              </div>
              <button
                onClick={() => onUpdateProfile({ animationsEnabled: !profile.animationsEnabled })}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                  profile.animationsEnabled ? 'bg-cyan-500 text-slate-950' : 'bg-slate-800 text-slate-400'
                }`}
              >
                {profile.animationsEnabled ? 'Activado' : 'Desactivado'}
              </button>
            </div>

            {/* Private Mode Toggle */}
            <div className="flex items-center justify-between p-3 rounded-xl bg-slate-950 border border-slate-800">
              <div className="flex items-center gap-2.5">
                {profile.privateModeHidden ? <EyeOff className="w-4 h-4 text-purple-400" /> : <Eye className="w-4 h-4 text-slate-400" />}
                <div>
                  <span className="text-xs font-bold text-white block">Modo Discreto para Hábitos Íntimos</span>
                  <span className="text-[11px] text-slate-400">Ocultar en widgets y tarjetas públicas</span>
                </div>
              </div>
              <button
                onClick={() => onUpdateProfile({ privateModeHidden: !profile.privateModeHidden })}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                  profile.privateModeHidden ? 'bg-purple-600 text-white' : 'bg-slate-800 text-slate-400'
                }`}
              >
                {profile.privateModeHidden ? 'Oculto' : 'Visible'}
              </button>
            </div>
          </div>

          {/* Backup & Data Persistence (100% Offline & Exportable) */}
          <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-xl space-y-3">
            <h2 className="text-sm font-black text-white font-rpg uppercase tracking-wider mb-2">
              Almacenamiento Local y Respaldo
            </h2>
            <p className="text-xs text-slate-400">
              Tus datos se guardan permanentemente en tu dispositivo (LocalStorage). Puedes exportar un archivo de respaldo cuando quieras.
            </p>

            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={onExportData}
                className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-400 text-xs font-bold border border-slate-700 transition"
              >
                <Download className="w-4 h-4" />
                <span>Exportar Copia JSON</span>
              </button>

              <button
                onClick={() => {
                  if (window.confirm('¿Deseas reiniciar los datos a la configuración inicial de demostración?')) {
                    onResetData();
                  }
                }}
                className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-slate-950 hover:bg-rose-950/40 text-rose-400 text-xs font-bold border border-rose-900/40 transition"
              >
                <RotateCcw className="w-4 h-4" />
                <span>Restablecer Demo</span>
              </button>
            </div>

            {/* Import JSON Area */}
            <div className="pt-2 border-t border-slate-800">
              <label className="block text-xs font-semibold text-slate-400 mb-1">
                Restaurar Copia de Seguridad
              </label>
              <textarea
                rows={2}
                value={importJsonText}
                onChange={(e) => setImportJsonText(e.target.value)}
                placeholder="Pega aquí el contenido del archivo JSON exportado..."
                className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white font-mono text-[10px] focus:outline-none focus:border-cyan-500 resize-none"
              />
              <button
                onClick={handleImportSubmit}
                className="mt-2 w-full flex items-center justify-center gap-1.5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold transition"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>Importar y Cargar Datos</span>
              </button>
              {importMessage && (
                <p className="mt-2 text-xs font-semibold text-cyan-300 text-center">
                  {importMessage}
                </p>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
