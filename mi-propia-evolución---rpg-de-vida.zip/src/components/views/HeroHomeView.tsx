import React from 'react';
import {
  PlayerProfile,
  HabitDefinition,
  HabitLog,
  AttributeState,
  AttributeKey,
  ViewAngle,
  CharacterPose,
} from '../../types/game';
import { CharacterCanvas } from '../character/CharacterCanvas';
import { WeeklyHabitProgress } from '../../utils/rpgCalculations';
import { getXPRequiredForLevel } from '../../utils/gameStorage';
import { soundEffects } from '../../utils/soundEffects';
import {
  CheckCircle2,
  Circle,
  Dumbbell,
  Footprints,
  Palette,
  Shield,
  TrendingUp,
  Sparkles,
  ChevronRight,
  Flame,
} from 'lucide-react';

interface HeroHomeViewProps {
  profile: PlayerProfile;
  habits: HabitDefinition[];
  todayLogs: HabitLog[];
  attributes: Record<AttributeKey, AttributeState>;
  weeklyProgress: WeeklyHabitProgress[];
  currentStreak: number;
  onQuickToggleHabit: (habitId: string) => void;
  onOpenHabitDetail: (habitId: string) => void;
  onNavigateToTab: (tab: any) => void;
  onUpdateAppearance: (changes: Partial<PlayerProfile['appearance']>) => void;
}

export const HeroHomeView: React.FC<HeroHomeViewProps> = ({
  profile,
  habits,
  todayLogs,
  attributes,
  weeklyProgress,
  currentStreak,
  onQuickToggleHabit,
  onOpenHabitDetail,
  onNavigateToTab,
  onUpdateAppearance,
}) => {
  const neededXP = getXPRequiredForLevel(profile.level);
  const xpPercentage = Math.min(Math.round((profile.currentXP / neededXP) * 100), 100);

  const getRankTitle = (level: number) => {
    if (level >= 25) return 'Maestro del Despertar';
    if (level >= 20) return 'Soberano de la Voluntad';
    if (level >= 15) return 'Guerrero Titán';
    if (level >= 10) return 'Atleta de Élite';
    if (level >= 5) return 'Cazador Emergente';
    return 'Iniciado del Camino';
  };

  const getHabitIcon = (id: string) => {
    switch (id) {
      case 'gym':
        return <Dumbbell className="w-4 h-4 text-blue-400" />;
      case 'running':
        return <Footprints className="w-4 h-4 text-cyan-400" />;
      case 'drawing':
        return <Palette className="w-4 h-4 text-amber-400" />;
      case 'abstinence':
        return <Shield className="w-4 h-4 text-purple-400" />;
      default:
        return <Flame className="w-4 h-4 text-cyan-400" />;
    }
  };

  // Filter habits if private mode hidden
  const visibleHabits = habits.filter((h) => !h.isPrivate || !profile.privateModeHidden);

  return (
    <div className="space-y-4 pb-20">
      {/* RPG HUD Level & XP Banner */}
      <div className="p-4 rounded-2xl bg-gradient-to-r from-slate-900 via-[#0e172a] to-slate-900 border border-slate-800 shadow-xl">
        <div className="flex items-center justify-between gap-2">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-cyan-400 uppercase tracking-wider">
                {getRankTitle(profile.level)}
              </span>
              <span className="text-slate-500">·</span>
              <span className="text-xs text-slate-400">Racha: {currentStreak} días</span>
            </div>
            <h1 className="text-lg font-black text-white font-rpg tracking-wide">
              {profile.name}
            </h1>
          </div>

          <div className="flex flex-col items-end">
            <span className="text-[10px] text-slate-400 font-semibold uppercase">Experiencia</span>
            <span className="text-xs font-bold text-cyan-300 font-mono-num">
              {profile.currentXP} / {neededXP} XP
            </span>
          </div>
        </div>

        {/* XP Progress Bar */}
        <div className="mt-2.5 relative w-full h-3 rounded-full bg-slate-950 border border-slate-800 overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-cyan-500 via-blue-500 to-indigo-500 transition-all duration-500 shadow-[0_0_12px_rgba(6,182,212,0.6)]"
            style={{ width: `${xpPercentage}%` }}
          />
        </div>
        <div className="mt-1 flex items-center justify-between text-[10px] text-slate-400">
          <span>Nivel {profile.level}</span>
          <span className="font-mono-num">{xpPercentage}% para Nivel {profile.level + 1}</span>
        </div>
      </div>

      {/* Main Character Stage */}
      <div className="relative p-3.5 rounded-3xl bg-gradient-to-b from-slate-900/90 via-[#0a101f] to-slate-950 border border-slate-800/80 shadow-2xl">
        <div className="flex items-center justify-between px-1 mb-2">
          <div className="flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            <span className="text-xs font-bold text-slate-300 uppercase tracking-wider font-rpg">
              Avatar y Evolución Física
            </span>
          </div>

          {/* Quick Aura Toggle */}
          <button
            onClick={() => {
              soundEffects.playClick();
              const auras = ['none', 'ki_blue', 'golden_super', 'crimson_rage', 'emerald_focus'] as const;
              const nextIdx = (auras.indexOf(profile.appearance.auraEffect as any) + 1) % auras.length;
              onUpdateAppearance({ auraEffect: auras[nextIdx] });
            }}
            className="text-[11px] font-semibold text-cyan-400 bg-cyan-950/60 border border-cyan-800/60 px-2 py-0.5 rounded-md hover:bg-cyan-900/40 transition"
          >
            Aura: {profile.appearance.auraEffect === 'none' ? 'Inactiva' : 'Activa'}
          </button>
        </div>

        {/* Parametric Character Rendering Engine */}
        <CharacterCanvas
          appearance={profile.appearance}
          weightKg={profile.currentWeightKg}
          bodyFatPercent={profile.currentBodyFatPercent}
          muscleMassKg={profile.currentMuscleMassKg}
          heightCm={profile.heightCm}
          level={profile.level}
          interactive={true}
          onViewChange={(view: ViewAngle) => onUpdateAppearance({ viewAngle: view })}
          onPoseChange={(pose: CharacterPose) => onUpdateAppearance({ currentPose: pose })}
        />

        {/* Motivation Bio Banner */}
        {profile.personalGoals && (
          <div className="mt-3 p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/80 text-xs text-slate-300">
            <span className="text-cyan-400 font-semibold block mb-0.5 text-[11px]">Objetivo del Guerrero:</span>
            <p className="line-clamp-2 italic text-slate-400">"{profile.personalGoals}"</p>
          </div>
        )}
      </div>

      {/* Today's Daily Missions Quick Actions */}
      <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800/80 shadow-lg">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <span className="text-sm font-bold text-white font-rpg">Misiones de Hoy</span>
            <span className="text-xs text-slate-400">· Toca para completar</span>
          </div>
          <button
            onClick={() => onNavigateToTab('missions')}
            className="text-xs font-semibold text-cyan-400 hover:text-cyan-300 flex items-center gap-0.5"
          >
            Ver todas <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          {visibleHabits.map((habit) => {
            const todayLog = todayLogs.find((l) => l.habitId === habit.id);
            const isCompleted = todayLog?.status === 'completed';

            return (
              <div
                key={habit.id}
                className={`flex items-center justify-between p-3 rounded-xl border transition-all ${
                  isCompleted
                    ? 'bg-emerald-950/30 border-emerald-500/40 text-emerald-200'
                    : 'bg-slate-950/70 border-slate-800 text-slate-300 hover:border-slate-700'
                }`}
              >
                <div
                  className="flex items-center gap-3 cursor-pointer flex-1 mr-2"
                  onClick={() => {
                    soundEffects.playClick();
                    onOpenHabitDetail(habit.id);
                  }}
                >
                  <div className="p-2 rounded-lg bg-slate-900 border border-slate-800 shrink-0">
                    {getHabitIcon(habit.id)}
                  </div>
                  <div className="min-w-0">
                    <h3 className="text-xs font-bold text-white truncate">{habit.name}</h3>
                    <div className="flex items-center gap-1.5 text-[10px] text-slate-400 mt-0.5">
                      <span className="text-cyan-400 font-mono-num font-semibold">+{habit.baseXP} XP</span>
                      <span>·</span>
                      <span className="truncate">{habit.category}</span>
                    </div>
                  </div>
                </div>

                {/* Instant Checkmark Button */}
                <button
                  onClick={() => onQuickToggleHabit(habit.id)}
                  title={isCompleted ? 'Marcar pendiente' : 'Marcar completada'}
                  className={`p-2 rounded-xl border transition-all active:scale-90 ${
                    isCompleted
                      ? 'bg-emerald-500 text-slate-950 border-emerald-400 shadow-sm shadow-emerald-500/30'
                      : 'bg-slate-900 border-slate-700 text-slate-500 hover:text-white hover:border-slate-500'
                  }`}
                >
                  {isCompleted ? <CheckCircle2 className="w-5 h-5" /> : <Circle className="w-5 h-5" />}
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* Character RPG Attributes Quick Summary */}
      <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800/80 shadow-lg">
        <div className="flex items-center justify-between mb-3">
          <span className="text-sm font-bold text-white font-rpg">Atributos del Personaje</span>
          <button
            onClick={() => onNavigateToTab('stats')}
            className="text-xs font-semibold text-cyan-400 hover:text-cyan-300 flex items-center gap-0.5"
          >
            Detalles <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
          {[
            { key: 'strength', name: 'Fuerza', state: attributes.strength, color: 'text-blue-400', bar: 'bg-blue-500' },
            { key: 'endurance', name: 'Resistencia', state: attributes.endurance, color: 'text-cyan-400', bar: 'bg-cyan-500' },
            { key: 'creativity', name: 'Creatividad', state: attributes.creativity, color: 'text-amber-400', bar: 'bg-amber-500' },
            { key: 'discipline', name: 'Disciplina', state: attributes.discipline, color: 'text-rose-400', bar: 'bg-rose-500' },
            { key: 'vitality', name: 'Vitalidad', state: attributes.vitality, color: 'text-emerald-400', bar: 'bg-emerald-500' },
          ].map((attr) => {
            const pct = Math.min(Math.round((attr.state.currentXP / attr.state.nextLevelXP) * 100), 100);
            return (
              <div key={attr.key} className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800/80">
                <div className="flex items-center justify-between text-xs font-medium">
                  <span className="text-slate-300">{attr.name}</span>
                  <span className={`font-black font-mono-num ${attr.color}`}>Nv.{attr.state.level}</span>
                </div>
                <div className="mt-2 w-full h-1.5 rounded-full bg-slate-900 overflow-hidden">
                  <div className={`h-full ${attr.bar}`} style={{ width: `${pct}%` }} />
                </div>
                <div className="mt-1 flex justify-between text-[9px] text-slate-500 font-mono-num">
                  <span>{attr.state.currentXP} XP</span>
                  <span>{pct}%</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Weekly Goal Tracker Strip */}
      <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800/80 shadow-lg">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-1.5">
            <TrendingUp className="w-4 h-4 text-emerald-400" />
            <span className="text-sm font-bold text-white font-rpg">Metas Semanales</span>
          </div>
          <button
            onClick={() => onNavigateToTab('missions')}
            className="text-xs font-semibold text-slate-400 hover:text-white"
          >
            Configurar
          </button>
        </div>

        <div className="space-y-2 mt-3">
          {weeklyProgress.map((wp) => (
            <div key={wp.habit.id} className="space-y-1">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-300 font-medium">{wp.habit.name}</span>
                <span className="text-slate-400 font-mono-num">
                  <strong className={wp.isGoalMet ? 'text-emerald-400' : 'text-white'}>
                    {wp.completedCount}
                  </strong>
                  {' / '}
                  {wp.goal} sesiones
                </span>
              </div>
              <div className="w-full h-2 rounded-full bg-slate-950 border border-slate-800 overflow-hidden">
                <div
                  className={`h-full transition-all duration-300 ${
                    wp.isGoalMet ? 'bg-emerald-500' : 'bg-cyan-500'
                  }`}
                  style={{ width: `${wp.percentage}%` }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
