import React, { useState } from 'react';
import { HabitDefinition, HabitLog, HabitId } from '../../types/game';
import {
  ChevronLeft,
  ChevronRight,
  CheckCircle2,
  Clock,
  XCircle,
  FileText,
  Filter,
  Flame,
  Plus,
} from 'lucide-react';

interface CalendarViewProps {
  habits: HabitDefinition[];
  logs: HabitLog[];
  onSelectDate: (date: string) => void;
  onOpenHabitLogModal: (habitId: string, date: string) => void;
}

export const CalendarView: React.FC<CalendarViewProps> = ({
  habits,
  logs,
  onSelectDate,
  onOpenHabitLogModal,
}) => {
  const [currentMonth, setCurrentMonth] = useState<Date>(new Date());
  const [selectedDay, setSelectedDay] = useState<string>(
    new Date().toISOString().split('T')[0]
  );
  const [selectedFilter, setSelectedFilter] = useState<string>('all');

  const year = currentMonth.getFullYear();
  const month = currentMonth.getMonth();

  // Days in month calculation
  const firstDayOfMonth = new Date(year, month, 1);
  const startingDayOfWeek = (firstDayOfMonth.getDay() + 6) % 7; // Monday as 0
  const daysInMonth = new Date(year, month + 1, 0).getDate();

  const prevMonth = () => {
    setCurrentMonth(new Date(year, month - 1, 1));
  };

  const nextMonth = () => {
    setCurrentMonth(new Date(year, month + 1, 1));
  };

  const monthNames = [
    'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
    'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'
  ];

  const weekDayNames = ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'];

  // Filter logs if filter is active
  const filteredLogs = selectedFilter === 'all'
    ? logs
    : logs.filter((l) => l.habitId === selectedFilter);

  // Group logs by date
  const logsByDate = new Map<string, HabitLog[]>();
  filteredLogs.forEach((log) => {
    const list = logsByDate.get(log.date) || [];
    list.push(log);
    logsByDate.set(log.date, list);
  });

  // Selected Day Details
  const selectedDayLogs = logs.filter((l) => l.date === selectedDay);
  const completedToday = selectedDayLogs.filter((l) => l.status === 'completed');
  const pendingToday = selectedDayLogs.filter((l) => l.status === 'pending');
  const skippedToday = selectedDayLogs.filter((l) => l.status === 'skipped');
  const xpEarnedToday = completedToday.reduce((sum, l) => sum + l.xpAwarded, 0);

  const todayStr = new Date().toISOString().split('T')[0];

  return (
    <div className="space-y-4 pb-20">
      {/* Month Navigation & Controls */}
      <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-xl">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-lg font-black text-white font-rpg tracking-wide">
              {monthNames[month]} {year}
            </h1>
            <p className="text-xs text-slate-400 mt-0.5">
              Patrones de constancia y registro histórico
            </p>
          </div>

          <div className="flex items-center gap-1.5 bg-slate-950 p-1 rounded-xl border border-slate-800">
            <button
              onClick={prevMonth}
              className="p-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800 transition"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={() => setCurrentMonth(new Date())}
              className="px-2 py-1 text-[11px] font-bold text-cyan-400 hover:text-cyan-300"
            >
              Hoy
            </button>
            <button
              onClick={nextMonth}
              className="p-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800 transition"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Filters Bar */}
        <div className="mt-4 flex items-center gap-1.5 overflow-x-auto pb-1">
          <span className="text-[11px] font-semibold text-slate-400 flex items-center gap-1 mr-1">
            <Filter className="w-3 h-3 text-cyan-400" /> Filtro:
          </span>
          <button
            onClick={() => setSelectedFilter('all')}
            className={`px-2.5 py-1 rounded-lg text-xs font-semibold whitespace-nowrap transition ${
              selectedFilter === 'all'
                ? 'bg-cyan-500 text-slate-950'
                : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            Todos los hábitos
          </button>
          {habits.map((habit) => (
            <button
              key={habit.id}
              onClick={() => setSelectedFilter(habit.id)}
              className={`px-2.5 py-1 rounded-lg text-xs font-semibold whitespace-nowrap transition ${
                selectedFilter === habit.id
                  ? 'bg-cyan-500 text-slate-950'
                  : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
              }`}
            >
              {habit.name}
            </button>
          ))}
        </div>
      </div>

      {/* Calendar Matrix */}
      <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-xl">
        {/* Days of week header */}
        <div className="grid grid-cols-7 gap-1 text-center mb-2">
          {weekDayNames.map((d) => (
            <div key={d} className="text-xs font-bold text-slate-400 py-1 font-rpg">
              {d}
            </div>
          ))}
        </div>

        {/* Days Grid */}
        <div className="grid grid-cols-7 gap-1.5">
          {/* Empty cells before month start */}
          {Array.from({ length: startingDayOfWeek }).map((_, i) => (
            <div key={`empty-${i}`} className="h-14 rounded-xl bg-slate-950/20" />
          ))}

          {/* Actual days of month */}
          {Array.from({ length: daysInMonth }).map((_, i) => {
            const dayNum = i + 1;
            const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(dayNum).padStart(2, '0')}`;
            const dayLogs = logsByDate.get(dateStr) || [];
            const completedCount = dayLogs.filter((l) => l.status === 'completed').length;
            const isSelected = selectedDay === dateStr;
            const isToday = todayStr === dateStr;

            return (
              <button
                key={dateStr}
                onClick={() => {
                  setSelectedDay(dateStr);
                  onSelectDate(dateStr);
                }}
                className={`relative flex flex-col items-center justify-between p-1 h-14 rounded-xl border transition-all text-left ${
                  isSelected
                    ? 'border-cyan-400 bg-cyan-950/50 shadow-md shadow-cyan-500/20 scale-[1.02]'
                    : isToday
                    ? 'border-blue-500/60 bg-blue-950/20'
                    : 'border-slate-800/80 bg-slate-950/60 hover:border-slate-700'
                }`}
              >
                <div className="w-full flex items-center justify-between px-1">
                  <span
                    className={`text-[11px] font-mono-num font-bold ${
                      isToday
                        ? 'text-cyan-400 font-black'
                        : isSelected
                        ? 'text-white'
                        : 'text-slate-300'
                    }`}
                  >
                    {dayNum}
                  </span>
                  {completedCount > 0 && (
                    <span className="text-[9px] font-bold text-emerald-400 font-mono-num">
                      {completedCount}
                    </span>
                  )}
                </div>

                {/* Habit completion dots */}
                <div className="flex items-center gap-0.5 mt-auto mb-1">
                  {dayLogs.slice(0, 4).map((l, idx) => {
                    const h = habits.find((hab) => hab.id === l.habitId);
                    return (
                      <span
                        key={idx}
                        className={`w-1.5 h-1.5 rounded-full ${
                          l.status === 'completed'
                            ? h?.id === 'gym'
                              ? 'bg-blue-400'
                              : h?.id === 'running'
                              ? 'bg-cyan-400'
                              : h?.id === 'drawing'
                              ? 'bg-amber-400'
                              : 'bg-purple-400'
                            : l.status === 'pending'
                            ? 'bg-amber-500/50'
                            : 'bg-slate-600'
                        }`}
                      />
                    );
                  })}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Selected Day Details Panel */}
      <div className="p-4 rounded-2xl bg-[#0d1527] border border-cyan-500/40 shadow-xl">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-bold text-white font-rpg">
                Detalle del Día: <span className="font-mono-num text-cyan-400">{selectedDay}</span>
              </h3>
              {selectedDay === todayStr && (
                <span className="px-2 py-0.5 rounded bg-cyan-950 text-cyan-400 text-[10px] font-bold">
                  Hoy
                </span>
              )}
            </div>
            <div className="flex items-center gap-2 text-xs text-slate-400 mt-1">
              <span>XP Obtenida: <strong className="text-cyan-300 font-mono-num font-bold">+{xpEarnedToday} XP</strong></span>
              <span>·</span>
              <span>{completedToday.length} completadas</span>
            </div>
          </div>

          <button
            onClick={() => onSelectDate(selectedDay)}
            className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold shadow-md shadow-cyan-500/20"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Editar Día</span>
          </button>
        </div>

        {/* Logs breakdown for that day */}
        <div className="mt-3 space-y-2">
          {selectedDayLogs.length === 0 ? (
            <div className="py-6 text-center text-xs text-slate-400">
              No hay actividades registradas en esta fecha.
              <div className="mt-2">
                <button
                  onClick={() => onOpenHabitLogModal(habits[0].id, selectedDay)}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-400 font-semibold"
                >
                  + Registrar actividad en {selectedDay}
                </button>
              </div>
            </div>
          ) : (
            selectedDayLogs.map((log) => {
              const h = habits.find((hab) => hab.id === log.habitId);
              return (
                <div
                  key={log.id}
                  className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center justify-between"
                >
                  <div className="flex items-center gap-2.5">
                    {log.status === 'completed' ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    ) : log.status === 'pending' ? (
                      <Clock className="w-4 h-4 text-amber-400 shrink-0" />
                    ) : (
                      <XCircle className="w-4 h-4 text-slate-400 shrink-0" />
                    )}
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-white">{h?.name || log.habitId}</span>
                        {log.metricValue && (
                          <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-800 text-cyan-300 font-mono-num">
                            {log.metricValue} {h?.metricUnit}
                          </span>
                        )}
                      </div>
                      {log.notes && (
                        <p className="text-[11px] text-slate-400 italic mt-0.5">"{log.notes}"</p>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono-num font-bold text-emerald-400">
                      {log.status === 'completed' ? `+${log.xpAwarded} XP` : '0 XP'}
                    </span>
                    <button
                      onClick={() => onOpenHabitLogModal(log.habitId, selectedDay)}
                      className="text-xs text-slate-400 hover:text-white p-1"
                    >
                      Editar
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
