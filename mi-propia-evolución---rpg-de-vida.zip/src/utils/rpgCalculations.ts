import {
  PlayerProfile,
  HabitLog,
  HabitDefinition,
  AttributeKey,
  AttributeState,
  Achievement,
  LevelUpEvent,
  BodyMeasurement,
} from '../types/game';
import { getXPRequiredForLevel } from './gameStorage';

export interface WeeklyHabitProgress {
  habit: HabitDefinition;
  completedCount: number;
  goal: number;
  percentage: number;
  isGoalMet: boolean;
}

export function calculateStreak(logs: HabitLog[]): { currentStreak: number; bestStreak: number } {
  // Extract unique dates where at least 1 mission was completed
  const completedDates = new Set(
    logs.filter((l) => l.status === 'completed').map((l) => l.date)
  );

  if (completedDates.size === 0) {
    return { currentStreak: 0, bestStreak: 0 };
  }

  const sortedDates = Array.from(completedDates).sort().reverse();
  const todayStr = new Date().toISOString().split('T')[0];
  const yesterday = new Date();
  yesterday.setDate(yesterday.getDate() - 1);
  const yesterdayStr = yesterday.toISOString().split('T')[0];

  // Check if active today or yesterday
  const hasRecent = sortedDates.includes(todayStr) || sortedDates.includes(yesterdayStr);
  if (!hasRecent) {
    return { currentStreak: 0, bestStreak: calculateMaxStreak(Array.from(completedDates)) };
  }

  let streak = 0;
  let checkDate = sortedDates.includes(todayStr) ? new Date() : yesterday;

  while (true) {
    const checkStr = checkDate.toISOString().split('T')[0];
    if (completedDates.has(checkStr)) {
      streak++;
      checkDate.setDate(checkDate.getDate() - 1);
    } else {
      break;
    }
  }

  const best = Math.max(streak, calculateMaxStreak(Array.from(completedDates)));
  return { currentStreak: streak, bestStreak: best };
}

function calculateMaxStreak(datesArray: string[]): number {
  if (datesArray.length === 0) return 0;
  const sorted = [...datesArray].sort();
  let max = 1;
  let curr = 1;

  for (let i = 1; i < sorted.length; i++) {
    const prev = new Date(sorted[i - 1]);
    const next = new Date(sorted[i]);
    const diffTime = Math.abs(next.getTime() - prev.getTime());
    const diffDays = Math.round(diffTime / (1000 * 60 * 60 * 24));

    if (diffDays === 1) {
      curr++;
      if (curr > max) max = curr;
    } else if (diffDays > 1) {
      curr = 1;
    }
  }
  return max;
}

/** Get start and end of current week (Monday to Sunday) */
export function getCurrentWeekDates(): { startOfWeek: string; endOfWeek: string; days: string[] } {
  const now = new Date();
  const day = now.getDay();
  // In JS: 0=Sun, 1=Mon, ..., 6=Sat
  const diffToMonday = day === 0 ? -6 : 1 - day;
  const monday = new Date(now);
  monday.setDate(now.getDate() + diffToMonday);

  const days: string[] = [];
  for (let i = 0; i < 7; i++) {
    const d = new Date(monday);
    d.setDate(monday.getDate() + i);
    days.push(d.toISOString().split('T')[0]);
  }

  return {
    startOfWeek: days[0],
    endOfWeek: days[6],
    days,
  };
}

export function calculateWeeklyProgress(
  habits: HabitDefinition[],
  logs: HabitLog[]
): WeeklyHabitProgress[] {
  const { startOfWeek, endOfWeek } = getCurrentWeekDates();
  const currentWeekLogs = logs.filter(
    (l) => l.date >= startOfWeek && l.date <= endOfWeek && l.status === 'completed'
  );

  return habits.map((habit) => {
    const count = currentWeekLogs.filter((l) => l.habitId === habit.id).length;
    const goal = habit.weeklyGoalSessions;
    const percentage = goal > 0 ? Math.min(Math.round((count / goal) * 100), 100) : 100;
    return {
      habit,
      completedCount: count,
      goal,
      percentage,
      isGoalMet: count >= goal,
    };
  });
}

/**
 * Calculates attribute progression (Fuerza, Resistencia, Creatividad, Disciplina, Vitalidad)
 * and detailed activity breakdown.
 */
export function calculateAttributes(
  logs: HabitLog[],
  habits: HabitDefinition[],
  streakCount: number
): Record<AttributeKey, AttributeState> {
  const habitMap = new Map(habits.map((h) => [h.id, h]));

  const totals: Record<AttributeKey, number> = {
    strength: 0,
    endurance: 0,
    creativity: 0,
    discipline: streakCount * 40, // Base discipline from continuous streaks
    vitality: 0,
  };

  const contributions: Record<AttributeKey, AttributeState['contributions']> = {
    strength: [],
    endurance: [],
    creativity: [],
    discipline: [],
    vitality: [],
  };

  logs.forEach((log) => {
    if (log.status !== 'completed') return;
    const habit = habitMap.get(log.habitId);
    if (!habit) return;

    const xp = log.xpAwarded || habit.baseXP;
    const primaryAttr = habit.primaryAttribute;
    const primaryShare = (habit.primaryAttrShare ?? 80) / 100;
    const primaryXP = Math.round(xp * primaryShare);

    totals[primaryAttr] = (totals[primaryAttr] || 0) + primaryXP;
    contributions[primaryAttr].push({
      habitId: habit.id,
      habitName: `${habit.name} (${Math.round(primaryShare * 100)}%)`,
      xp: primaryXP,
      date: log.date,
    });

    // Secondary attribute distribution
    if (habit.secondaryAttribute && habit.secondaryAttribute !== 'none') {
      const secondaryAttr = habit.secondaryAttribute;
      const secondaryShare = (habit.secondaryAttrShare ?? 20) / 100;
      const secondaryXP = Math.round(xp * secondaryShare);

      totals[secondaryAttr] = (totals[secondaryAttr] || 0) + secondaryXP;
      contributions[secondaryAttr].push({
        habitId: habit.id,
        habitName: `${habit.name} (${Math.round(secondaryShare * 100)}%)`,
        xp: secondaryXP,
        date: log.date,
      });
    }

    // Passive discipline gain from any completed effort
    totals.discipline += Math.floor(xp * 0.1);
  });

  const keys: AttributeKey[] = ['strength', 'endurance', 'creativity', 'discipline', 'vitality'];
  const result = {} as Record<AttributeKey, AttributeState>;

  keys.forEach((key) => {
    const totalXP = totals[key];
    // Formula for attribute levels: level = Math.floor(Math.sqrt(totalXP / 80)) + 1
    const level = Math.max(1, Math.floor(Math.sqrt(totalXP / 90)) + 1);
    const xpForThisLevel = Math.floor(90 * Math.pow(level - 1, 2));
    const xpForNextLevel = Math.floor(90 * Math.pow(level, 2));
    const currentXPInLevel = Math.max(0, totalXP - xpForThisLevel);
    const neededForNext = Math.max(50, xpForNextLevel - xpForThisLevel);

    result[key] = {
      level,
      currentXP: currentXPInLevel,
      nextLevelXP: neededForNext,
      totalXP,
      contributions: contributions[key].slice(-10).reverse(), // Last 10 contributions
    };
  });

  return result;
}

/** Check if player leveled up after gaining XP */
export function checkLevelUp(profile: PlayerProfile, gainedXP: number): {
  updatedProfile: PlayerProfile;
  levelUpEvent: LevelUpEvent | null;
} {
  let level = profile.level;
  let currentXP = profile.currentXP + gainedXP;
  let totalXP = profile.totalXP + gainedXP;
  let neededXP = getXPRequiredForLevel(level);
  let oldLevel = profile.level;
  let leveledUp = false;

  while (currentXP >= neededXP) {
    currentXP -= neededXP;
    level++;
    leveledUp = true;
    neededXP = getXPRequiredForLevel(level);
  }

  const updatedProfile: PlayerProfile = {
    ...profile,
    level,
    currentXP,
    totalXP,
  };

  let levelUpEvent: LevelUpEvent | null = null;
  if (leveledUp) {
    levelUpEvent = {
      newLevel: level,
      oldLevel,
      titleUnlocked:
        level >= 20 ? 'Soberano de la Voluntad' :
        level >= 15 ? 'Campeón Shonen' :
        level >= 10 ? 'Guerrero de Élite' :
        level >= 5 ? 'Atleta Despierto' : 'Iniciado Firme',
      attributeBoosts: {
        strength: (level - oldLevel) * 2,
        endurance: (level - oldLevel) * 2,
        creativity: (level - oldLevel) * 2,
        discipline: (level - oldLevel) * 2,
        vitality: (level - oldLevel) * 2,
      },
    };
  }

  return { updatedProfile, levelUpEvent };
}

/** Evaluates all achievements and marks newly unlocked ones */
export function evaluateAchievements(
  achievements: Achievement[],
  logs: HabitLog[],
  profile: PlayerProfile,
  measurements: BodyMeasurement[]
): { updatedAchievements: Achievement[]; newlyUnlocked: Achievement[] } {
  const newlyUnlocked: Achievement[] = [];
  const completedLogs = logs.filter((l) => l.status === 'completed');

  const gymCount = completedLogs.filter((l) => l.habitId === 'gym').length;
  const runCount = completedLogs.filter((l) => l.habitId === 'running').length;
  const drawCount = completedLogs.filter((l) => l.habitId === 'drawing').length;
  const streak = calculateStreak(logs).currentStreak;

  // Body fat drop calculation
  const initialBF = measurements.length > 0 ? measurements[0].bodyFatPercent : profile.currentBodyFatPercent;
  const currentBF = profile.currentBodyFatPercent;
  const fatReduction = Math.max(0, initialBF - currentBF);

  const updatedAchievements = achievements.map((ach) => {
    let currentVal = ach.currentValue;

    if (ach.id === 'first_gym') currentVal = gymCount;
    else if (ach.id === 'first_run') currentVal = runCount;
    else if (ach.id === 'first_draw') currentVal = drawCount;
    else if (ach.id === 'streak_3') currentVal = streak;
    else if (ach.id === 'running_10_total') currentVal = runCount;
    else if (ach.id === 'draw_streak_7') currentVal = drawCount;
    else if (ach.id === 'body_fat_drop') currentVal = parseFloat(fatReduction.toFixed(1));
    else if (ach.id === 'level_5') currentVal = profile.level;
    else if (ach.id === 'streak_14') currentVal = streak;

    const isNowUnlocked = currentVal >= ach.targetValue;

    if (isNowUnlocked && !ach.isUnlocked) {
      const unlockedAch: Achievement = {
        ...ach,
        currentValue: currentVal,
        isUnlocked: true,
        unlockedAt: new Date().toISOString().split('T')[0],
      };
      newlyUnlocked.push(unlockedAch);
      return unlockedAch;
    }

    return {
      ...ach,
      currentValue: currentVal,
    };
  });

  return { updatedAchievements, newlyUnlocked };
}
