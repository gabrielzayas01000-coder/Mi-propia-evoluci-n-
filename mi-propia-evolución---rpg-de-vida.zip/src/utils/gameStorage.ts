import {
  PlayerProfile,
  BodyMeasurement,
  HabitDefinition,
  HabitLog,
  Achievement,
  AttributeKey,
  AttributeState,
  LevelUpEvent,
} from '../types/game';

const STORAGE_KEYS = {
  PROFILE: 'rpg_evolucion_profile_v1',
  MEASUREMENTS: 'rpg_evolucion_measurements_v1',
  HABIT_CONFIGS: 'rpg_evolucion_habit_configs_v1',
  HABIT_LOGS: 'rpg_evolucion_habit_logs_v1',
  ACHIEVEMENTS: 'rpg_evolucion_achievements_v1',
  ATTRIBUTES: 'rpg_evolucion_attributes_v1',
};

export const DEFAULT_HABITS: HabitDefinition[] = [
  {
    id: 'gym',
    name: 'Gimnasio',
    category: 'Entrenamiento de Fuerza',
    description: 'Levantamiento de pesas, hipertrofia y fuerza funcional.',
    iconName: 'Dumbbell',
    primaryAttribute: 'strength',
    secondaryAttribute: 'discipline',
    primaryAttrShare: 75,
    secondaryAttrShare: 25,
    baseXP: 75,
    metricBonusRate: 2, // +2 XP por serie
    weeklyGoalBonusXP: 250,
    streakBonusXP: 20,
    weeklyGoalSessions: 4,
    metricLabel: 'Ejercicios / Grupos musculares',
    metricUnit: 'series',
    isPrivate: false,
    color: '#3b82f6', // blue
  },
  {
    id: 'running',
    name: 'Correr',
    category: 'Cardio y Resistencia',
    description: 'Carrera continua, intervalos y capacidad pulmonar.',
    iconName: 'Footprints',
    primaryAttribute: 'endurance',
    secondaryAttribute: 'vitality',
    primaryAttrShare: 80,
    secondaryAttrShare: 20,
    baseXP: 65,
    metricBonusRate: 10, // +10 XP por km
    weeklyGoalBonusXP: 200,
    streakBonusXP: 20,
    weeklyGoalSessions: 4,
    metricLabel: 'Distancia recorrida',
    metricUnit: 'km',
    isPrivate: false,
    color: '#06b6d4', // cyan
  },
  {
    id: 'drawing',
    name: 'Dibujar',
    category: 'Arte y Creatividad',
    description: 'Práctica de anatomía, bocetos, entintado o ilustración.',
    iconName: 'Palette',
    primaryAttribute: 'creativity',
    secondaryAttribute: 'discipline',
    primaryAttrShare: 85,
    secondaryAttrShare: 15,
    baseXP: 50,
    metricBonusRate: 1, // +1 XP por cada 2 minutos
    weeklyGoalBonusXP: 300,
    streakBonusXP: 15,
    weeklyGoalSessions: 7,
    metricLabel: 'Tiempo de práctica',
    metricUnit: 'minutos',
    isPrivate: false,
    color: '#f59e0b', // amber
  },
  {
    id: 'abstinence',
    name: 'Autocontrol & Enfoque',
    category: 'Objetivo Personal Privado',
    description: 'Gestión saludable de impulsos y abstinencia consciente.',
    iconName: 'Shield',
    primaryAttribute: 'vitality',
    secondaryAttribute: 'discipline',
    primaryAttrShare: 70,
    secondaryAttrShare: 30,
    baseXP: 60,
    metricBonusRate: 0,
    weeklyGoalBonusXP: 200,
    streakBonusXP: 25,
    weeklyGoalSessions: 7,
    metricLabel: 'Cumplimiento del día',
    metricUnit: 'día',
    isPrivate: true,
    color: '#a855f7', // purple
  },
];

export const INITIAL_ACHIEVEMENTS: Achievement[] = [
  {
    id: 'first_gym',
    title: 'Primer Paso de Hierro',
    description: 'Completa tu primera sesión de gimnasio registrada.',
    category: 'gym',
    icon: 'Dumbbell',
    xpReward: 100,
    currentValue: 1,
    targetValue: 1,
    isUnlocked: true,
    unlockedAt: '2026-10-02',
  },
  {
    id: 'first_run',
    title: 'El Despertar del Viento',
    description: 'Registra tu primera sesión de carrera.',
    category: 'running',
    icon: 'Footprints',
    xpReward: 100,
    currentValue: 1,
    targetValue: 1,
    isUnlocked: true,
    unlockedAt: '2026-10-03',
  },
  {
    id: 'first_draw',
    title: 'Trazo Despierto',
    description: 'Dedica tiempo a tu cuaderno de bocetos o tableta gráfica.',
    category: 'drawing',
    icon: 'Palette',
    xpReward: 80,
    currentValue: 1,
    targetValue: 1,
    isUnlocked: true,
    unlockedAt: '2026-10-04',
  },
  {
    id: 'streak_3',
    title: 'Chispa de Disciplina',
    description: 'Mantén una racha de 3 días consecutivos con actividades.',
    category: 'discipline',
    icon: 'Flame',
    xpReward: 150,
    currentValue: 3,
    targetValue: 3,
    isUnlocked: true,
    unlockedAt: '2026-10-05',
  },
  {
    id: 'gym_week_4',
    title: 'Semana de Poder',
    description: 'Completa tus 4 sesiones de gimnasio en una misma semana.',
    category: 'gym',
    icon: 'Trophy',
    xpReward: 250,
    cosmeticReward: 'Pose de Fuerza Desbloqueada',
    currentValue: 3,
    targetValue: 4,
    isUnlocked: false,
  },
  {
    id: 'running_10_total',
    title: 'Fondo Inquebrantable',
    description: 'Acumula 10 sesiones totales de carrera.',
    category: 'running',
    icon: 'Zap',
    xpReward: 300,
    cosmeticReward: 'Título: Corredor Relámpago',
    currentValue: 6,
    targetValue: 10,
    isUnlocked: false,
  },
  {
    id: 'draw_streak_7',
    title: 'Mente Creadora',
    description: 'Dibuja 7 días consecutivos sin fallar.',
    category: 'drawing',
    icon: 'Sparkles',
    xpReward: 300,
    cosmeticReward: 'Aura Esmeralda de Foco',
    currentValue: 4,
    targetValue: 7,
    isUnlocked: false,
  },
  {
    id: 'body_fat_drop',
    title: 'Metamorfosis Física',
    description: 'Reduce tu porcentaje de grasa corporal en al menos 2% respecto al inicio.',
    category: 'evolution',
    icon: 'TrendingDown',
    xpReward: 400,
    cosmeticReward: 'Atuendo de Entrenamiento Élite',
    currentValue: 1.5,
    targetValue: 2,
    isUnlocked: false,
  },
  {
    id: 'level_5',
    title: 'Superando el Límite',
    description: 'Alcanza el Nivel 5 de personaje.',
    category: 'general',
    icon: 'Crown',
    xpReward: 500,
    cosmeticReward: 'Efecto de Aura Ki Azul',
    currentValue: 3,
    targetValue: 5,
    isUnlocked: false,
  },
  {
    id: 'streak_14',
    title: 'Fuego Interior',
    description: 'Alcanza una racha legendaria de 14 días activos.',
    category: 'discipline',
    icon: 'Flame',
    xpReward: 600,
    cosmeticReward: 'Aura Carmesí de Furia',
    currentValue: 5,
    targetValue: 14,
    isUnlocked: false,
  },
];

export const INITIAL_MEASUREMENTS: BodyMeasurement[] = [
  {
    id: 'm-1',
    date: '2026-09-20',
    weightKg: 89.2,
    bodyFatPercent: 28.5,
    muscleMassKg: 33.1,
    waistCm: 96,
    notes: 'Inicio de la aventura. Complexión gruesa, barriga prominente y poca resistencia.',
    isManual: true,
    calculatedImc: 28.1,
  },
  {
    id: 'm-2',
    date: '2026-10-04',
    weightKg: 87.5,
    bodyFatPercent: 27.2,
    muscleMassKg: 33.8,
    waistCm: 94,
    notes: 'Dos semanas de entrenamiento. Mejor postura y energía.',
    isManual: true,
    calculatedImc: 27.6,
  },
  {
    id: 'm-3',
    date: '2026-10-15',
    weightKg: 85.8,
    bodyFatPercent: 25.8,
    muscleMassKg: 34.4,
    waistCm: 91,
    notes: 'Disminución notable del volumen de la cintura. Mayor fuerza en press y dominadas.',
    isManual: true,
    calculatedImc: 27.0,
  },
];

export const INITIAL_PROFILE: PlayerProfile = {
  id: 'player-gabriel',
  name: 'Gabriel',
  age: 25,
  heightCm: 178,
  currentWeightKg: 85.8,
  currentBodyFatPercent: 25.8,
  currentMuscleMassKg: 34.4,
  level: 3,
  currentXP: 210,
  totalXP: 810,
  startDate: '2026-09-20',
  personalGoals: 'Alcanzar 14% de grasa corporal, desarrollar hombros y espalda atléticos, correr 10k fluidos y dibujar a diario.',
  characterBio: 'Un protagonista en su arco de entrenamiento y despertar de potencial.',
  targetDescription: 'Un hombre atlético, fuerte, creativo, con mente serena y disciplina inquebrantable.',
  appearance: {
    skinTone: '#e0a97d',
    hairStyle: 'anime_messy',
    hairColor: '#1e1b18',
    eyeColor: '#38bdf8',
    eyeStyle: 'heroic_sharp',
    faceShape: 'sharp_v',
    facialHair: 'stubble',
    facialHairColor: '#1e1b18',
    outfit: 'gym_tank',
    outfitColor: '#2563eb',
    accessory: 'wrist_wraps',
    katanaOnBack: false,
    auraEffect: 'ki_blue',
    artStyle: 'anime',
    currentPose: 'idle',
    viewAngle: 'front',
  },
  soundEnabled: true,
  animationsEnabled: true,
  privateModeHidden: false,
};

// Seed sample habit logs for current and past weeks so calendar & stats are immediately rich
export function generateInitialLogs(): HabitLog[] {
  const logs: HabitLog[] = [];
  const today = new Date();
  
  // Seed past 14 days
  for (let i = 13; i >= 0; i--) {
    const d = new Date(today);
    d.setDate(d.getDate() - i);
    const dateStr = d.toISOString().split('T')[0];
    const dayOfWeek = d.getDay(); // 0 is Sun, 6 is Sat

    // Gym: 4 days/week (Mon=1, Wed=3, Fri=5, Sat=6)
    if ([1, 3, 5, 6].includes(dayOfWeek) && i !== 2) {
      logs.push({
        id: `log-gym-${dateStr}`,
        habitId: 'gym',
        date: dateStr,
        status: 'completed',
        sessionsCount: 1,
        metricValue: 18, // 18 series
        notes: dayOfWeek === 1 ? 'Torso y hombros' : dayOfWeek === 3 ? 'Piernas y core' : 'Espalda y bíceps',
        xpAwarded: 75,
        timestamp: `${dateStr}T18:30:00Z`,
      });
    }

    // Running: 3-4 days/week (Tue=2, Thu=4, Sat=6, Sun=0)
    if ([2, 4, 0].includes(dayOfWeek) && i !== 7) {
      logs.push({
        id: `log-run-${dateStr}`,
        habitId: 'running',
        date: dateStr,
        status: 'completed',
        sessionsCount: 1,
        metricValue: 4.5 + (13 - i) * 0.2, // km
        notes: 'Ritmo cómodo de respiración nasal',
        xpAwarded: 65,
        timestamp: `${dateStr}T07:15:00Z`,
      });
    }

    // Drawing: almost daily
    if (i !== 4 && i !== 9) {
      logs.push({
        id: `log-draw-${dateStr}`,
        habitId: 'drawing',
        date: dateStr,
        status: 'completed',
        sessionsCount: 1,
        metricValue: 40, // minutes
        notes: 'Bocetos de anatomía y perspectiva dinámica',
        xpAwarded: 50,
        timestamp: `${dateStr}T21:00:00Z`,
      });
    }

    // Abstinence / Focus: daily
    if (i !== 8) {
      logs.push({
        id: `log-ab-${dateStr}`,
        habitId: 'abstinence',
        date: dateStr,
        status: 'completed',
        sessionsCount: 1,
        metricValue: 1,
        notes: 'Día con mente clara y sin distracciones',
        xpAwarded: 60,
        timestamp: `${dateStr}T22:30:00Z`,
      });
    }
  }

  return logs;
}

export function getXPRequiredForLevel(level: number): number {
  return Math.floor(120 * Math.pow(level, 1.35));
}

export class GameStorageManager {
  public static getProfile(): PlayerProfile {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.PROFILE);
      if (data) {
        const parsed = JSON.parse(data);
        return {
          ...INITIAL_PROFILE,
          ...parsed,
          appearance: {
            ...INITIAL_PROFILE.appearance,
            ...(parsed.appearance || {}),
          },
        };
      }
    } catch {
      // Fallback
    }
    this.saveProfile(INITIAL_PROFILE);
    return INITIAL_PROFILE;
  }

  public static saveProfile(profile: PlayerProfile): void {
    try {
      localStorage.setItem(STORAGE_KEYS.PROFILE, JSON.stringify(profile));
    } catch {
      // Ignore
    }
  }

  public static getMeasurements(): BodyMeasurement[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.MEASUREMENTS);
      if (data) return JSON.parse(data);
    } catch {
      // Fallback
    }
    this.saveMeasurements(INITIAL_MEASUREMENTS);
    return INITIAL_MEASUREMENTS;
  }

  public static saveMeasurements(records: BodyMeasurement[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.MEASUREMENTS, JSON.stringify(records));
    } catch {
      // Ignore
    }
  }

  public static getHabits(): HabitDefinition[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.HABIT_CONFIGS);
      if (data) {
        const parsed: HabitDefinition[] = JSON.parse(data);
        // Merge with defaults to ensure all properties exist
        return parsed.map((h) => {
          const def = DEFAULT_HABITS.find((d) => d.id === h.id);
          return {
            ...(def || {}),
            ...h,
            primaryAttrShare: h.primaryAttrShare ?? def?.primaryAttrShare ?? 80,
            secondaryAttrShare: h.secondaryAttrShare ?? def?.secondaryAttrShare ?? 20,
            metricBonusRate: h.metricBonusRate ?? def?.metricBonusRate ?? 0,
            weeklyGoalBonusXP: h.weeklyGoalBonusXP ?? def?.weeklyGoalBonusXP ?? 200,
            streakBonusXP: h.streakBonusXP ?? def?.streakBonusXP ?? 15,
          } as HabitDefinition;
        });
      }
    } catch {
      // Fallback
    }
    this.saveHabits(DEFAULT_HABITS);
    return DEFAULT_HABITS;
  }

  public static saveHabits(habits: HabitDefinition[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.HABIT_CONFIGS, JSON.stringify(habits));
    } catch {
      // Ignore
    }
  }

  public static getLogs(): HabitLog[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.HABIT_LOGS);
      if (data) return JSON.parse(data);
    } catch {
      // Fallback
    }
    const initial = generateInitialLogs();
    this.saveLogs(initial);
    return initial;
  }

  public static saveLogs(logs: HabitLog[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.HABIT_LOGS, JSON.stringify(logs));
    } catch {
      // Ignore
    }
  }

  public static getAchievements(): Achievement[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.ACHIEVEMENTS);
      if (data) return JSON.parse(data);
    } catch {
      // Fallback
    }
    this.saveAchievements(INITIAL_ACHIEVEMENTS);
    return INITIAL_ACHIEVEMENTS;
  }

  public static saveAchievements(achs: Achievement[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.ACHIEVEMENTS, JSON.stringify(achs));
    } catch {
      // Ignore
    }
  }

  public static exportAllData(): string {
    const exportObject = {
      exportVersion: '1.0',
      exportedAt: new Date().toISOString(),
      profile: this.getProfile(),
      measurements: this.getMeasurements(),
      habits: this.getHabits(),
      logs: this.getLogs(),
      achievements: this.getAchievements(),
    };
    return JSON.stringify(exportObject, null, 2);
  }

  public static importAllData(jsonString: string): boolean {
    try {
      const parsed = JSON.parse(jsonString);
      if (parsed.profile) this.saveProfile(parsed.profile);
      if (parsed.measurements) this.saveMeasurements(parsed.measurements);
      if (parsed.habits) this.saveHabits(parsed.habits);
      if (parsed.logs) this.saveLogs(parsed.logs);
      if (parsed.achievements) this.saveAchievements(parsed.achievements);
      return true;
    } catch {
      return false;
    }
  }

  public static resetToInitial(): void {
    this.saveProfile(INITIAL_PROFILE);
    this.saveMeasurements(INITIAL_MEASUREMENTS);
    this.saveHabits(DEFAULT_HABITS);
    this.saveLogs(generateInitialLogs());
    this.saveAchievements(INITIAL_ACHIEVEMENTS);
  }
}
