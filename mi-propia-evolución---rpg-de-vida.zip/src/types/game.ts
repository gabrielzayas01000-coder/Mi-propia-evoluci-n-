export type ViewAngle = 'front' | 'side' | 'back';

export type CharacterPose = 'idle' | 'strength' | 'running' | 'drawing' | 'zen';

export type BodyBuild = 'heavy' | 'medium' | 'athletic' | 'muscular_beast';

export type HairStyle = 'anime_messy' | 'short_spiky' | 'supersaiyan' | 'undercut' | 'long_warrior' | 'ponytail' | 'buzz';

export type EyeStyle = 'heroic_sharp' | 'focused_calm' | 'fiery_warrior' | 'mystic';

export type FacialHair = 'none' | 'stubble' | 'beard_short' | 'goatee';

export type OutfitType = 'gym_tank' | 'hoodie_athlete' | 'elite_armor' | 'monk_gi' | 'shadow_assassin';

export type AccessoryType = 'none' | 'headband' | 'wrist_wraps' | 'scouter' | 'power_necklace' | 'katana_back' | 'fox_mask';

export type AuraEffect = 'none' | 'ki_blue' | 'golden_super' | 'crimson_rage' | 'shadow_void' | 'emerald_focus';

export type ArtStyle = 'anime' | 'manhwa' | 'minimalist';

export type FaceShape = 'sharp_v' | 'athletic_jaw' | 'soft';

export interface CharacterAppearance {
  skinTone: string;
  hairStyle: HairStyle;
  hairColor: string;
  eyeColor: string;
  eyeStyle: EyeStyle;
  faceShape: FaceShape;
  facialHair: FacialHair;
  facialHairColor: string;
  outfit: OutfitType;
  outfitColor: string;
  accessory: AccessoryType;
  katanaOnBack: boolean;
  auraEffect: AuraEffect;
  artStyle: ArtStyle;
  currentPose: CharacterPose;
  viewAngle: ViewAngle;
}

export interface PlayerProfile {
  id: string;
  name: string;
  avatarUrl?: string;
  age: number;
  heightCm: number;
  currentWeightKg: number;
  currentBodyFatPercent: number;
  currentMuscleMassKg?: number;
  
  // Game progression
  level: number;
  currentXP: number;
  totalXP: number;
  startDate: string; // YYYY-MM-DD
  
  // Character story
  personalGoals: string;
  characterBio: string;
  targetDescription: string;
  
  // Customization
  appearance: CharacterAppearance;
  
  // Preferences
  soundEnabled: boolean;
  animationsEnabled: boolean;
  privateModeHidden: boolean; // Hide intimate habit from public cards/widgets
}

export interface BodyMeasurement {
  id: string;
  date: string; // YYYY-MM-DD
  weightKg: number;
  bodyFatPercent: number;
  muscleMassKg?: number;
  waistCm?: number;
  chestCm?: number;
  armsCm?: number;
  notes?: string;
  isManual: boolean;
  calculatedImc: number;
}

export type HabitId = 'gym' | 'running' | 'drawing' | 'abstinence' | string;

export type AttributeKey = 'strength' | 'endurance' | 'creativity' | 'discipline' | 'vitality';

export interface AttributeDefinition {
  key: AttributeKey;
  name: string;
  description: string;
  icon: string;
  color: string;
  relatedHabit: HabitId | 'all';
}

export interface AttributeState {
  level: number;
  currentXP: number;
  nextLevelXP: number;
  totalXP: number;
  contributions: {
    habitId: string;
    habitName: string;
    xp: number;
    date: string;
  }[];
}

export interface HabitDefinition {
  id: string;
  name: string;
  category: string;
  description: string;
  iconName: string;
  primaryAttribute: AttributeKey;
  secondaryAttribute?: AttributeKey | 'none';
  primaryAttrShare: number; // Percentage e.g. 75
  secondaryAttrShare: number; // Percentage e.g. 25
  baseXP: number;
  metricBonusRate: number; // Extra XP per metric unit (e.g. +10 XP per km or +5 XP per 10 mins)
  weeklyGoalBonusXP: number; // Bonus on achieving the goal
  streakBonusXP: number; // Bonus if on a streak
  weeklyGoalSessions: number;
  metricLabel: string;
  metricUnit: string;
  isPrivate: boolean;
  color: string;
  isCustom?: boolean;
}

export type HabitStatus = 'completed' | 'pending' | 'skipped';

export interface HabitLog {
  id: string;
  habitId: string;
  date: string; // YYYY-MM-DD
  status: HabitStatus;
  sessionsCount: number;
  metricValue?: number; // e.g. km ran, minutes drawn, exercises completed
  notes?: string;
  xpAwarded: number;
  timestamp: string;
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  category: 'gym' | 'running' | 'drawing' | 'discipline' | 'evolution' | 'general';
  icon: string;
  xpReward: number;
  cosmeticReward?: string;
  currentValue: number;
  targetValue: number;
  isUnlocked: boolean;
  unlockedAt?: string;
}

export interface LevelUpEvent {
  newLevel: number;
  oldLevel: number;
  titleUnlocked?: string;
  attributeBoosts: Record<AttributeKey, number>;
}
